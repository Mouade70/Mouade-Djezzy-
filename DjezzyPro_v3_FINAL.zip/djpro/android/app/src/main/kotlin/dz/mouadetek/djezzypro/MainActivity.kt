// من تطوير معاذ جلال | @MouadeTEK | 🇩🇿
package dz.mouadetek.djezzypro
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
