import '../services/djezzy_api.dart';

// من تطوير معاذ جلال | @MouadeTEK

class MgmRecord {
  final String phone;
  final List<DateTime> activations;
  const MgmRecord({required this.phone, required this.activations});
  int get countInPeriod { final c=DateTime.now().subtract(const Duration(days:16)); return activations.where((d)=>d.isAfter(c)).length; }
  bool get canActivate => countInPeriod < 5;
  int get daysUntilNextSlot {
    if (canActivate) return 0;
    final sorted=List.of(activations)..sort();
    final cutoff=DateTime.now().subtract(const Duration(days:16));
    final oldest=sorted.firstWhere((d)=>d.isAfter(cutoff),orElse:()=>DateTime.now());
    return oldest.add(const Duration(days:16)).difference(DateTime.now()).inDays.clamp(1,16)+1;
  }
  MgmRecord addActivation()=>MgmRecord(phone:phone,activations:[...activations,DateTime.now()]);
  factory MgmRecord.empty(String phone)=>MgmRecord(phone:phone,activations:[]);
  Map<String,dynamic> toJson()=>{'phone':phone,'activations':activations.map((d)=>d.toIso8601String()).toList()};
  factory MgmRecord.fromJson(Map<String,dynamic> j)=>MgmRecord(
    phone:j['phone'] as String?? '',
    activations:((j['activations'] as List?)??[]).map((s)=>DateTime.tryParse(s as String)??DateTime.now()).toList(),
  );
}

class ActRecord {
  final int count; final DateTime? lastDate;
  const ActRecord({this.count=0,this.lastDate});
  ActRecord increment()=>ActRecord(count:count+1,lastDate:DateTime.now());
  String get lastDateStr=>lastDate==null?'':'${lastDate!.year}-${lastDate!.month.toString().padLeft(2,'0')}-${lastDate!.day.toString().padLeft(2,'0')}';
  Map<String,dynamic> toJson()=>{'count':count,'lastDate':lastDate?.toIso8601String()};
  factory ActRecord.fromJson(dynamic j){
    if(j==null) return const ActRecord();
    final m=j as Map<String,dynamic>;
    return ActRecord(count:m['count'] as int??0,lastDate:m['lastDate']!=null?DateTime.tryParse(m['lastDate'] as String):null);
  }
}

class AccountModel {
  final String phone,token,label;
  final SimType simType;
  final DateTime lastUsed;
  const AccountModel({required this.phone,required this.token,this.simType=SimType.djezzy,this.label='',required this.lastUsed});
  String get displayLabel=>label.isNotEmpty?label:localPhone(phone);
  String get maskedPhone =>maskPhone(phone);
  int get simColor=>switch(simType){SimType.zid=>0xFFE91E63,SimType.legend=>0xFF8B5CF6,SimType.izzy=>0xFF10B981,SimType.control=>0xFF0EA5E9,SimType.postpaid=>0xFF64748B,SimType.djezzy=>0xFFFF5500};
  AccountModel copyWith({String? phone,String? token,SimType? simType,String? label,DateTime? lastUsed})=>AccountModel(phone:phone??this.phone,token:token??this.token,simType:simType??this.simType,label:label??this.label,lastUsed:lastUsed??this.lastUsed);
  Map<String,dynamic> toJson()=>{'phone':phone,'token':token,'simType':simType.name,'label':label,'lastUsed':lastUsed.toIso8601String()};
  factory AccountModel.fromJson(Map<String,dynamic> j)=>AccountModel(
    phone:j['phone'] as String??'',token:j['token'] as String??'',
    simType:SimType.values.firstWhere((s)=>s.name==j['simType'],orElse:()=>SimType.djezzy),
    label:j['label'] as String??'',
    lastUsed:DateTime.tryParse(j['lastUsed'] as String?? '')??DateTime.now(),
  );
}

class UssdCode {
  final String code,description; final bool isFree; final String? category;
  const UssdCode({required this.code,required this.description,this.isFree=true,this.category});
}

const List<UssdCode> allUssdCodes=[
  UssdCode(code:'*710#',  description:'رصيد الحساب (مجاني)',    isFree:true, category:'رصيد'),
  UssdCode(code:'*777#',  description:'رصيد الحساب (بديل)',      isFree:true, category:'رصيد'),
  UssdCode(code:'*720#',  description:'تفعيل العروض',            isFree:true, category:'عروض'),
  UssdCode(code:'*707#',  description:'باقات الإنترنت',          isFree:true, category:'إنترنت'),
  UssdCode(code:'*707*3#',description:'رصيد الإنترنت المتبقي',  isFree:true, category:'إنترنت'),
  UssdCode(code:'*707*2#',description:'مشاركة الإنترنت',         isFree:true, category:'إنترنت'),
  UssdCode(code:'*99#',   description:'رقمك الخاص',             isFree:true, category:'حساب'),
  UssdCode(code:'*727#',  description:'خدمة VERSO+',            isFree:true, category:'خدمات'),
  UssdCode(code:'*787#',  description:'معلومات الفاتورة',        isFree:true, category:'فاتورة'),
  UssdCode(code:'700',    description:'إعادة الشحن (مجاني)',    isFree:true, category:'شحن'),
  UssdCode(code:'777',    description:'خدمة العملاء',           isFree:false,category:'دعم'),
  UssdCode(code:'710',    description:'رصيد الحساب (5 DA)',     isFree:false,category:'رصيد'),
  UssdCode(code:'718',    description:'دليل الأعمال',            isFree:false,category:'دعم'),
  UssdCode(code:'0770857777',description:'خدمة العملاء VIP',    isFree:false,category:'دعم'),
];
