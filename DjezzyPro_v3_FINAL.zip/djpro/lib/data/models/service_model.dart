import 'package:flutter/material.dart';
import '../services/djezzy_api.dart';

// من تطوير معاذ جلال | @MouadeTEK

enum ServiceCategory { free, paid, control }
enum ServiceActionType { walk, mgm, hack3gb, offer }

class DjezzyService {
  final String id, name, nameAr, subtitle, data, validity;
  final ServiceCategory category;
  final IconData icon;
  final Color color;
  final int price, maxTries;
  final String? packageCode, badge;
  final ServiceActionType actionType;
  final String failMessage;
  final SimType? requiredSim;

  const DjezzyService({
    required this.id, required this.category, required this.icon,
    required this.name, required this.nameAr, required this.subtitle,
    required this.data, required this.validity, required this.color,
    this.price=0, this.packageCode, required this.actionType,
    this.maxTries=2, required this.failMessage, this.requiredSim, this.badge,
  });
}

final List<DjezzyService> allServices = [
  // FREE
  DjezzyService(id:'w2g',  category:ServiceCategory.free,  icon:Icons.directions_walk_rounded,   name:'Walk 2GB',         nameAr:'مشي ابدا',           subtitle:'مكافأة المشي اليومي',          data:'2 GB',  validity:'يومي',   color:Color(0xFFFF5500), packageCode:'GIFTWALKWIN2GO', actionType:ServiceActionType.walk,  maxTries:2, failMessage:'تأكد أن حسابك مؤهل لـ Walk & Win'),
  DjezzyService(id:'w1g',  category:ServiceCategory.free,  icon:Icons.directions_run_rounded,    name:'Walk 1GB',         nameAr:'مشي ابدا',           subtitle:'مكافأة المشي اليومي',          data:'1 GB',  validity:'يومي',   color:Color(0xFFFF8C00), packageCode:'GIFTWALKWIN1GO', actionType:ServiceActionType.walk,  maxTries:2, failMessage:'تأكد أن حسابك مؤهل لـ Walk & Win'),
  DjezzyService(id:'wkl',  category:ServiceCategory.free,  icon:Icons.card_giftcard_rounded,     name:'هدية أسبوعية',    nameAr:'هدية الأسبوع',      subtitle:'هدية ولاء الأسبوع',            data:'2 GB',  validity:'7 أيام', color:Color(0xFF00C896), packageCode:'GIFTWEEKLY2GO',  actionType:ServiceActionType.walk,  maxTries:2, failMessage:'⚖️ القانون الجديد: يجب تفعيل 100 DA شهرياً'),
  DjezzyService(id:'mgm',  category:ServiceCategory.free,  icon:Icons.people_alt_rounded,        name:'MGM 1GB',          nameAr:'ادعُ صديقاً',       subtitle:'ادعُ صديقاً واحصل على 1GB',  data:'1 GB',  validity:'شهري',   color:Color(0xFF3B82F6), packageCode:null,            actionType:ServiceActionType.mgm,   maxTries:50,failMessage:'فشل بعد 50 محاولة. تأكد من أهلية حسابك', badge:'5/16j'),
  DjezzyService(id:'h3g',  category:ServiceCategory.free,  icon:Icons.bolt_rounded,              name:'3GB مجاناً',      nameAr:'ثلاثة جيجا',        subtitle:'Walk 2GB + Walk 1GB',          data:'3 GB',  validity:'يومي',   color:Color(0xFFDC2626), packageCode:null,            actionType:ServiceActionType.hack3gb,maxTries:2, failMessage:'فشل — الحساب غير مؤهل أو سبق التفعيل', badge:'COMBO'),
  // PAID
  DjezzyService(id:'d70',  category:ServiceCategory.paid,  icon:Icons.data_usage_rounded,        name:'عرض 70 DA',        nameAr:'عرض سبعين',         subtitle:'4GB لمدة 7 أيام',              data:'4 GB',  validity:'7 أيام', color:Color(0xFFD97706), packageCode:'OFFRE70DA4GO',   actionType:ServiceActionType.offer, maxTries:1, failMessage:'تحقق من رصيدك', price:70),
  DjezzyService(id:'d100', category:ServiceCategory.paid,  icon:Icons.wifi_rounded,              name:'عرض 100 DA',       nameAr:'عرض مية',           subtitle:'5GB لمدة 7 أيام',              data:'5 GB',  validity:'7 أيام', color:Color(0xFF8B5CF6), packageCode:'OFFRE100DA5GO',  actionType:ServiceActionType.offer, maxTries:1, failMessage:'تحقق من رصيدك', price:100),
  DjezzyService(id:'d200', category:ServiceCategory.paid,  icon:Icons.rocket_launch_rounded,     name:'عرض 200 DA',       nameAr:'عرض ميتين',         subtitle:'10GB لمدة شهر',                data:'10 GB', validity:'شهري',   color:Color(0xFF6D28D9), packageCode:'OFFRE200DA10GO', actionType:ServiceActionType.offer, maxTries:1, failMessage:'تحقق من رصيدك', price:200),
  DjezzyService(id:'z200', category:ServiceCategory.paid,  icon:Icons.diamond_rounded,           name:'ZID 200 DA',       nameAr:'زيد ميتين',         subtitle:'2GB + مكالمات / 7 أيام',     data:'2 GB',  validity:'7 أيام', color:Color(0xFFE91E63), packageCode:'ZID200',         actionType:ServiceActionType.offer, maxTries:1, failMessage:'ZID 200 لشريحة ZID فقط', price:200,  requiredSim:SimType.zid),
  DjezzyService(id:'z400', category:ServiceCategory.paid,  icon:Icons.local_fire_department_rounded,name:'ZID 400 DA',   nameAr:'زيد أربعمية',       subtitle:'4GB + مكالمات / 15 يوم',     data:'4 GB',  validity:'15 يوم', color:Color(0xFF9C27B0), packageCode:'ZID400',         actionType:ServiceActionType.offer, maxTries:1, failMessage:'ZID 400 لشريحة ZID فقط', price:400,  requiredSim:SimType.zid),
  DjezzyService(id:'z1k',  category:ServiceCategory.paid,  icon:Icons.stars_rounded,             name:'ZID 1000 DA',      nameAr:'زيد ألف',           subtitle:'15GB + مكالمات شهري',         data:'15 GB', validity:'شهري',   color:Color(0xFF8B5CF6), packageCode:'ZID1000',        actionType:ServiceActionType.offer, maxTries:1, failMessage:'ZID 1000 لشريحة ZID فقط', price:1000, requiredSim:SimType.zid),
  DjezzyService(id:'hyd',  category:ServiceCategory.paid,  icon:Icons.water_drop_rounded,        name:'Hayla يومي',       nameAr:'هايلة يومي',        subtitle:'1GB يومياً',                   data:'1 GB',  validity:'يومي',   color:Color(0xFF0284C7), packageCode:'HAYLADAILY',     actionType:ServiceActionType.offer, maxTries:1, failMessage:'فشل تفعيل Hayla', price:100),
  DjezzyService(id:'hyw',  category:ServiceCategory.paid,  icon:Icons.waves_rounded,             name:'Hayla أسبوعي',     nameAr:'هايلة أسبوعي',      subtitle:'5GB أسبوعياً',                 data:'5 GB',  validity:'7 أيام', color:Color(0xFF0369A1), packageCode:'HAYLAWEEKLY',    actionType:ServiceActionType.offer, maxTries:1, failMessage:'فشل تفعيل Hayla', price:300),
  DjezzyService(id:'hym',  category:ServiceCategory.paid,  icon:Icons.emoji_events_rounded,      name:'Hayla شهري',       nameAr:'هايلة شهري',        subtitle:'50GB شهرياً',                  data:'50 GB', validity:'شهري',   color:Color(0xFF0891B2), packageCode:'HAYLAMONTHLY',   actionType:ServiceActionType.offer, maxTries:1, failMessage:'فشل تفعيل Hayla', price:1200),
  DjezzyService(id:'lg50', category:ServiceCategory.paid,  icon:Icons.workspace_premium_rounded, name:'Legend 50GB',      nameAr:'ليجاند خمسين',      subtitle:'50GB + مكالمات ∞',            data:'50 GB', validity:'شهري',   color:Color(0xFF8B5CF6), packageCode:'LEGEND50GO',     actionType:ServiceActionType.offer, maxTries:1, failMessage:'Legend لشريحة Legend فقط', price:2000, requiredSim:SimType.legend),
  DjezzyService(id:'lg80', category:ServiceCategory.paid,  icon:Icons.auto_awesome_rounded,      name:'Legend 80GB',      nameAr:'ليجاند ثمانين',      subtitle:'80GB + مكالمات ∞',            data:'80 GB', validity:'شهري',   color:Color(0xFF6D28D9), packageCode:'LEGEND80GO',     actionType:ServiceActionType.offer, maxTries:1, failMessage:'Legend لشريحة Legend فقط', price:2500, requiredSim:SimType.legend),
  DjezzyService(id:'hbl',  category:ServiceCategory.paid,  icon:Icons.phone_in_talk_rounded,     name:'HBAL 1000 DA',     nameAr:'حبال ألف',           subtitle:'مكالمات ∞ شهري',              data:'–',     validity:'شهري',   color:Color(0xFF374151), packageCode:'HBAL1000',       actionType:ServiceActionType.offer, maxTries:1, failMessage:'فشل تفعيل HBAL', price:1000),
  // CONTROL
  DjezzyService(id:'ctrl', category:ServiceCategory.control,icon:Icons.sim_card_rounded,         name:'Control SIM',      nameAr:'تحكم في الشريحة',   subtitle:'إعدادات شريحتك',               data:'–',     validity:'–',      color:Color(0xFF0EA5E9), packageCode:null,            actionType:ServiceActionType.offer, maxTries:1, failMessage:''),
  DjezzyService(id:'par',  category:ServiceCategory.control,icon:Icons.family_restroom_rounded,  name:'Parental Control', nameAr:'الرقابة الأبوية',   subtitle:'التحكم في حساب الأبناء',       data:'–',     validity:'–',      color:Color(0xFF10B981), packageCode:null,            actionType:ServiceActionType.offer, maxTries:1, failMessage:''),
];
