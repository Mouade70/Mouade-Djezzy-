import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import '../constants/api_constants.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — Service API Direct                      ║
// ║   من مطور معاذ جلال | @MouadeTEK | 🇩🇿               ║
// ╚══════════════════════════════════════════════════════════╝

class ApiResult<T> {
  final bool ok;
  final int status;
  final T? data;
  final String? message;
  final String? error;

  const ApiResult({
    required this.ok,
    required this.status,
    this.data,
    this.message,
    this.error,
  });
}

class DjezzyApiService {
  DjezzyApiService._();
  static final DjezzyApiService instance = DjezzyApiService._();

  final _client = http.Client();
  final _rng    = Random();

  static const _baseHeaders = {
    'User-Agent':      'MobileApp/3.0.0',
    'Accept':          'application/json',
    'Content-Type':    'application/json',
    'accept-language': 'ar',
    'Connection':      'keep-alive',
  };

  Map<String, String> _authH(String token) => {
    ..._baseHeaders,
    'authorization': token.startsWith('Bearer') ? token : 'Bearer $token',
  };

  // ─── Phone utilities (copied from Python format_num) ──────
  static String normPhone(String raw) {
    final p = raw.replaceAll(RegExp(r'\D'), '');
    if (p.startsWith('0')   && p.length == 10) return '213${p.substring(1)}';
    if (p.startsWith('213') && p.length == 12) return p;
    if (!p.startsWith('213')) return '213$p';
    return p;
  }

  static String localPhone(String p) =>
      p.startsWith('213') ? '0${p.substring(3)}' : p;

  static String maskPhone(String p) {
    final l = localPhone(p);
    if (l.length < 6) return p;
    return '${l.substring(0, 4)}••••${l.substring(l.length - 2)}';
  }

  // ─── generate_random_djezzy_no (EXACT copy from Python) ───
  String _randomDjezzyPhone() {
    final prefixes = ['077', '078', '079'];
    final prefix   = prefixes[_rng.nextInt(3)];
    final digits   = List.generate(7, (_) => _rng.nextInt(10)).join();
    return normPhone('$prefix$digits');
  }

  // ─── Core HTTP ────────────────────────────────────────────
  Future<ApiResult<Map>> _post(
    String path, {
    Map<String, dynamic>? jsonBody,
    Map<String, String>? formBody,
    String? token,
    Map<String, String>? params,
  }) async {
    try {
      var uri = Uri.parse(ApiConstants.baseUrl + path);
      if (params != null) uri = uri.replace(queryParameters: params);

      final headers = Map<String, String>.from(
        token != null ? _authH(token) : _baseHeaders,
      );
      if (formBody != null) {
        headers['Content-Type'] = 'application/x-www-form-urlencoded';
      }

      final body = formBody != null
          ? formBody.entries.map((e) => '${e.key}=${Uri.encodeComponent(e.value)}').join('&')
          : jsonEncode(jsonBody ?? {});

      final res = await _client
          .post(uri, headers: headers, body: body)
          .timeout(const Duration(seconds: 15));

      Map<String, dynamic> d = {};
      try { d = jsonDecode(res.body); } catch (_) {}

      return ApiResult(
        ok: [200, 201].contains(res.statusCode),
        status: res.statusCode,
        data: d,
        message: d['message'] as String? ?? d['description'] as String?,
      );
    } catch (e) {
      return ApiResult(ok: false, status: 0, error: e.toString());
    }
  }

  Future<ApiResult<Map>> _get(String path, String token) async {
    try {
      final res = await _client
          .get(Uri.parse(ApiConstants.baseUrl + path), headers: _authH(token))
          .timeout(const Duration(seconds: 15));
      Map<String, dynamic> d = {};
      try { d = jsonDecode(res.body); } catch (_) {}
      return ApiResult(ok: res.statusCode == 200, status: res.statusCode, data: d);
    } catch (e) {
      return ApiResult(ok: false, status: 0, error: e.toString());
    }
  }

  // ─── AUTH ─────────────────────────────────────────────────
  /// request_otp — يرسل OTP لأي رقم
  Future<ApiResult<Map>> sendOtp(String phone) => _post(
    ApiConstants.registration,
    jsonBody: {
      'consent-agreement': [{'marketing-notifications': false}],
      'is-consent': true,
    },
    params: {
      'msisdn':    phone,
      'client_id': ApiConstants.clientId,
      'scope':     'smsotp',
    },
  );

  /// login_with_otp — يرجع access_token
  Future<String?> verifyOtp(String phone, String otp) async {
    final r = await _post(
      ApiConstants.token,
      formBody: {
        'otp':          otp,
        'mobileNumber': phone,
        'scope':        'djezzyAppV2',
        'client_id':    ApiConstants.clientId,
        'client_secret':ApiConstants.clientSecret,
        'grant_type':   'mobile',
      },
    );
    if (!r.ok) return null;
    final t = r.data?['access_token'] as String?;
    return t != null ? 'Bearer $t' : null;
  }

  // ─── SUBSCRIBER ───────────────────────────────────────────
  Future<SubInfo> getAllInfo(String phone, String token) async {
    final results = await Future.wait([
      _get(ApiConstants.mainBalance(phone),   token),
      _get(ApiConstants.internetBalance(phone), token),
      _get(ApiConstants.subscriberInfo(phone), token),
    ]);

    final bR = results[0]; final nR = results[1]; final iR = results[2];

    String? bal = bR.data?['balance']?.toString();
    if (bal == null || bal == 'null') bal = (bR.data?['data'] as Map?)?['balance']?.toString();

    double? rem = _toDouble(nR.data, ['data','remainingData','remainingMb','value']);
    double? tot = _toDouble(nR.data, ['total','totalData','totalMb']);
    String? exp = _toStr(nR.data, ['expiryDate','validity','endDate']);

    return SubInfo(
      balance:     bal,
      bonus:       bR.data?['bonus']?.toString(),
      remainingMb: rem,
      totalMb:     tot,
      expiry:      exp,
      simType:     _detectSim(iR.data),
    );
  }

  double? _toDouble(Map? d, List<String> keys) {
    for (final k in keys) {
      final v = d?[k];
      if (v != null && v.toString() != 'null') {
        final n = double.tryParse(v.toString());
        if (n != null && n > 0) return n;
      }
    }
    return null;
  }

  String? _toStr(Map? d, List<String> keys) {
    for (final k in keys) {
      final v = d?[k]?.toString();
      if (v != null && v.isNotEmpty && v != 'null') return v;
    }
    return null;
  }

  SimType _detectSim(Map? d) {
    if (d == null) return SimType.djezzy;
    final raw = jsonEncode(d).toLowerCase();
    if (raw.contains('legend'))   return SimType.legend;
    if (raw.contains('izzy'))     return SimType.izzy;
    if (raw.contains('zid'))      return SimType.zid;
    if (raw.contains('control'))  return SimType.control;
    if (raw.contains('postpaid')) return SimType.postpaid;
    return SimType.djezzy;
  }

  // ─── WALK & WIN ───────────────────────────────────────────
  Future<ApiResult<Map>> activateWalk(String phone, String token, String pkg) =>
      _post(ApiConstants.walkReward(phone), jsonBody: {'packageCode': pkg}, token: token);

  Future<Map<String, bool>> activate3GB(String phone, String token) async {
    final r1 = await activateWalk(phone, token, 'GIFTWALKWIN2GO');
    await Future.delayed(const Duration(milliseconds: 500));
    final r2 = await activateWalk(phone, token, 'GIFTWALKWIN1GO');
    return {'2gb': r1.ok, '1gb': r2.ok};
  }

  // ─── MGM — منقول حرفياً من Python script معاذ جلال ──────
  /// الخوارزمية الأصلية من 1Go_v1.py:
  /// 1. توليد رقم عشوائي (077/078/079 + 7 أرقام)
  /// 2. send-invitation للرقم العشوائي
  /// 3. request_otp للرقم العشوائي (تسجيله)
  /// 4. انتظار ثانيتين
  /// 5. activate-reward للمرسل
  /// 6. تكرار حتى 50 مرة أو النجاح
  Future<ApiResult<Map>> activateMgm(
    String phone,
    String token, {
    void Function(int attempt, int total, String status)? onProgress,
  }) async {
    const maxAttempts = 50;

    for (int attempt = 0; attempt < maxAttempts; attempt++) {
      try {
        // STEP 1: توليد رقم عشوائي
        final target = _randomDjezzyPhone();
        onProgress?.call(attempt + 1, maxAttempts, 'إرسال دعوة لـ ${target.substring(target.length - 4)}...');

        // STEP 2: send_invitation — إرسال الدعوة
        final inv = await _post(
          ApiConstants.mgmInvite(phone),
          jsonBody: {'msisdnReciever': target},
          token: token,
        );

        if (inv.ok) {
          // STEP 3: request_otp — تسجيل الرقم المستهدف
          await sendOtp(target);

          // STEP 4: انتظار ثانيتين (كما في البوت الأصلي)
          onProgress?.call(attempt + 1, maxAttempts, 'تفعيل المكافأة...');
          await Future.delayed(const Duration(seconds: 2));

          // STEP 5: activate_reward — تفعيل المكافأة للمرسل
          final reward = await _post(
            ApiConstants.mgmReward(phone),
            jsonBody: {'packageCode': 'MGMBONUS1Go'},
            token: token,
          );

          if (reward.ok) {
            return ApiResult(
              ok: true,
              status: reward.status,
              message: '✅ تم تفعيل 1GB MGM على شريحتك 🎉',
              data: reward.data,
            );
          }
        }
      } catch (e) {
        // تجاهل الأخطاء والاستمرار (كما في البوت الأصلي)
      }

      // انتظار ثانية بين المحاولات
      await Future.delayed(const Duration(seconds: 1));
    }

    return const ApiResult(
      ok: false,
      status: 0,
      message: '❌ فشل التفعيل — وصلت للحد الأقصى للمحاولات',
    );
  }

  // ─── OFFERS ───────────────────────────────────────────────
  Future<ApiResult<Map>> activateOffer(String phone, String token, String pkg) async {
    for (final ep in [
      ApiConstants.offerActivate(phone),
      ApiConstants.addonsSubscribe(phone),
      ApiConstants.offersSubscribe(phone),
    ]) {
      final r = await _post(ep, jsonBody: {'packageCode': pkg}, token: token);
      if (r.ok || (r.status > 0 && r.status != 404)) return r;
    }
    return const ApiResult(ok: false, status: 404, message: 'العرض غير متاح');
  }

  // ─── RECHARGE بكود (جديد) ─────────────────────────────────
  Future<ApiResult<Map>> rechargeByCode(String phone, String token, String code) =>
      _post(ApiConstants.recharge(phone), jsonBody: {'rechargeCode': code}, token: token);

  Future<ApiResult<Map>> rechargeGift(String phone, String token, String target, int amount) =>
      _post(ApiConstants.rechargeGift(phone), jsonBody: {'recipientMsisdn': target, 'amount': amount}, token: token);

  // ─── DATA SHARING ─────────────────────────────────────────
  Future<ApiResult<Map>> shareData(String phone, String token, String target, int mb) =>
      _post(ApiConstants.dataShare(phone), jsonBody: {'recipientMsisdn': target, 'dataAmount': mb}, token: token);

  // ─── HISTORY ──────────────────────────────────────────────
  Future<ApiResult<Map>> getHistory(String phone, String token) =>
      _get(ApiConstants.history(phone), token);

  Future<ApiResult<Map>> getActiveOffers(String phone, String token) =>
      _get(ApiConstants.activeOffers(phone), token);
}

// ─── Enums & Models ───────────────────────────────────────────────────────
enum SimType { djezzy, zid, legend, izzy, control, postpaid }

extension SimTypeX on SimType {
  String get label => switch (this) {
    SimType.djezzy   => 'Djezzy',
    SimType.zid      => 'Djezzy ZID',
    SimType.legend   => 'Legend',
    SimType.izzy     => 'Izzy',
    SimType.control  => 'Control',
    SimType.postpaid => 'Postpaid',
  };
  String get emoji => switch (this) {
    SimType.djezzy   => '📱',
    SimType.zid      => '💎',
    SimType.legend   => '👑',
    SimType.izzy     => '🌟',
    SimType.control  => '🎛',
    SimType.postpaid => '💳',
  };
}

class SubInfo {
  final String? balance;
  final String? bonus;
  final double? remainingMb;
  final double? totalMb;
  final String? expiry;
  final SimType simType;

  const SubInfo({
    this.balance, this.bonus, this.remainingMb,
    this.totalMb, this.expiry,
    this.simType = SimType.djezzy,
  });

  double get usagePct {
    if (remainingMb == null || totalMb == null || totalMb == 0) return 0;
    return ((totalMb! - remainingMb!) / totalMb! * 100).clamp(0, 100);
  }

  String get dataStr {
    if (remainingMb == null) return '---';
    return remainingMb! >= 1024
        ? '${(remainingMb! / 1024).toStringAsFixed(2)} GB'
        : '${remainingMb!.toInt()} MB';
  }

  SubInfo copyWith({
    String? balance, String? bonus, double? remainingMb,
    double? totalMb, String? expiry, SimType? simType,
  }) => SubInfo(
    balance: balance ?? this.balance,
    bonus: bonus ?? this.bonus,
    remainingMb: remainingMb ?? this.remainingMb,
    totalMb: totalMb ?? this.totalMb,
    expiry: expiry ?? this.expiry,
    simType: simType ?? this.simType,
  );
}
