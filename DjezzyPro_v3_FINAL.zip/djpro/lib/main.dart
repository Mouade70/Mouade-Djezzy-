import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'core/theme/app_colors.dart';
import 'presentation/providers/app_provider.dart';
import 'presentation/screens/splash/splash_screen.dart';
import 'presentation/screens/auth/auth_screen.dart';
import 'presentation/screens/main_shell.dart';
import 'presentation/screens/mgm/mgm_screen.dart';
import 'presentation/screens/walk/walk_screen.dart';
import 'presentation/screens/recharge/recharge_screen.dart';
import 'presentation/screens/ussd/ussd_screen.dart';
import 'presentation/screens/share/share_screen.dart';
import 'presentation/screens/history/history_screen.dart';
import 'presentation/screens/speed/speed_screen.dart';
import 'presentation/screens/network/network_screen.dart';
import 'presentation/screens/notifications/notifications_screen.dart';
import 'presentation/screens/profile/profile_screen.dart';
import 'presentation/screens/about/about_screen.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro v3.0.0                                    ║
// ║   من تطوير معاذ جلال | @MouadeTEK | 🇩🇿              ║
// ║   dz.mouadetek.djezzypro                               ║
// ╚══════════════════════════════════════════════════════════╝

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.darkBg,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  final prov = AppProvider();
  await prov.init();
  runApp(ChangeNotifierProvider.value(value:prov, child:const DjezzyProApp()));
}

class DjezzyProApp extends StatelessWidget {
  const DjezzyProApp({super.key});
  @override
  Widget build(BuildContext context) => Consumer<AppProvider>(
    builder:(_,__,___) => MaterialApp(
      title: 'Djezzy Pro',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      themeMode: ThemeMode.dark,
      routes: {
        '/':              (_) => const SplashScreen(),
        '/auth':          (_) => const AuthScreen(),
        '/main':          (_) => const MainShell(),
        '/mgm':           (_) => const MgmScreen(),
        '/walk':          (_) => const WalkScreen(),
        '/recharge':      (_) => const RechargeScreen(),
        '/ussd':          (_) => const UssdScreen(),
        '/share':         (_) => const ShareScreen(),
        '/history':       (_) => const HistoryScreen(),
        '/speed':         (_) => const SpeedScreen(),
        '/network':       (_) => const NetworkScreen(),
        '/notifications': (_) => const NotificationsScreen(),
        '/profile':       (_) => const ProfileScreen(),
        '/about':         (_) => const AboutScreen(),
      },
      initialRoute: '/',
    ),
  );
}
