import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/models/models.dart';
import '../../data/models/service_model.dart';
import '../../data/services/djezzy_api.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — State Management (MVVM)                 ║
// ║   من مطور معاذ جلال | @MouadeTEK | 🇩🇿               ║
// ╚══════════════════════════════════════════════════════════╝

class AppProvider extends ChangeNotifier {
  final _api = DjezzyApiService.instance;
  late SharedPreferences _prefs;

  AccountModel? _session;
  List<AccountModel> _accounts = [];
  SubInfo _subInfo  = const SubInfo();
  bool _subLoading         = false;
  bool _initialized        = false;
  Map<String, SvcState> _svcStates = {};
  MgmRecord? _mgmRecord;
  Map<String, ActRecord> _activations = {};
  bool _darkMode = true;

  AccountModel?      get session    => _session;
  bool               get isLoggedIn => _session != null;
  List<AccountModel> get accounts   => _accounts;
  SubInfo     get subInfo    => _subInfo;
  bool               get subLoading => _subLoading;
  bool               get initialized=> _initialized;
  bool               get darkMode   => _darkMode;

  SvcState svcState(String id) =>
      _svcStates[id] ?? const SvcState();

  MgmRecord get mgmRecord =>
      _mgmRecord ?? MgmRecord.empty(_session?.phone ?? '');

  ActRecord activationRecord(String serviceId) =>
      _activations['${_session?.phone}:$serviceId'] ?? const ActRecord();

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _loadAccounts();
    _loadSession();
    _loadActivations();
    _darkMode = _prefs.getBool('dark_mode') ?? true;
    _initialized = true;
    notifyListeners();
    if (_session != null) {
      _loadMgmRecord();
      loadSubInfo();
    }
  }

  // ─── Persistence ─────────────────────────────────────────
  void _loadAccounts() {
    final raw  = _prefs.getString('djpro_accounts') ?? '[]';
    final list = jsonDecode(raw) as List;
    _accounts  = list.map((j) => AccountModel.fromJson(j as Map<String, dynamic>)).toList();
  }
  void _saveAccounts() => _prefs.setString('djpro_accounts', jsonEncode(_accounts.map((a) => a.toJson()).toList()));

  void _loadSession() {
    final raw = _prefs.getString('djpro_session');
    if (raw != null) try { _session = AccountModel.fromJson(jsonDecode(raw) as Map<String, dynamic>); } catch (_) {}
  }
  void _saveSession() {
    if (_session == null) _prefs.remove('djpro_session');
    else _prefs.setString('djpro_session', jsonEncode(_session!.toJson()));
  }

  void _loadActivations() {
    final raw = _prefs.getString('djpro_activations') ?? '{}';
    final map = jsonDecode(raw) as Map<String, dynamic>;
    _activations = map.map((k, v) => MapEntry(k, ActRecord.fromJson(v as Map<String, dynamic>?)));
  }
  void _saveActivations() => _prefs.setString('djpro_activations', jsonEncode(_activations.map((k, v) => MapEntry(k, v.toJson()))));

  void _loadMgmRecord() {
    final raw = _prefs.getString('djpro_mgm_${_session?.phone}');
    if (raw != null) try { _mgmRecord = MgmRecord.fromJson(jsonDecode(raw) as Map<String, dynamic>); } catch (_) {}
  }
  void _saveMgmRecord() {
    if (_mgmRecord != null) _prefs.setString('djpro_mgm_${_session?.phone}', jsonEncode(_mgmRecord!.toJson()));
  }

  // ─── Auth ─────────────────────────────────────────────────
  Future<bool> sendOtp(String phone) async {
    final r = await _api.sendOtp(phone);
    return r.ok;
  }

  Future<bool> verifyOtp(String phone, String otp) async {
    final token = await _api.verifyOtp(phone, otp);
    if (token == null) return false;

    final account = AccountModel(phone: phone, token: token, lastUsed: DateTime.now());
    _session = account;
    _saveSession();

    final idx = _accounts.indexWhere((a) => a.phone == phone);
    if (idx >= 0) _accounts[idx] = account;
    else _accounts.add(account);
    _saveAccounts();

    _loadMgmRecord();
    notifyListeners();
    loadSubInfo();
    return true;
  }

  void logout() {
    _session = null;
    _subInfo = const SubInfo();
    _mgmRecord = null;
    _saveSession();
    notifyListeners();
  }

  void switchAccount(AccountModel account) {
    _session = account.copyWith(lastUsed: DateTime.now());
    _saveSession();
    _subInfo = const SubInfo();
    _loadMgmRecord();
    notifyListeners();
    loadSubInfo();
  }

  void deleteAccount(String phone) {
    _accounts.removeWhere((a) => a.phone == phone);
    _saveAccounts();
    if (_session?.phone == phone) logout();
    else notifyListeners();
  }

  // ─── Subscriber ───────────────────────────────────────────
  Future<void> loadSubInfo() async {
    if (_session == null) return;
    _subLoading = true;
    notifyListeners();
    try {
      final info = await _api.getAllInfo(_session!.phone, _session!.token);
      _subInfo = info;
      // Update sim type in account list
      final idx = _accounts.indexWhere((a) => a.phone == _session!.phone);
      if (idx >= 0) {
        _accounts[idx] = _accounts[idx].copyWith(simType: info.simType);
        _session = _session!.copyWith(simType: info.simType);
        _saveAccounts(); _saveSession();
      }
    } catch (e) { debugPrint('[AppProvider] loadSubInfo: $e'); }
    _subLoading = false;
    notifyListeners();
  }

  void refreshSubInfo() => loadSubInfo();

  // ─── Service Activation ───────────────────────────────────
  Future<void> activateService(DjezzyService service) async {
    if (_session == null) return;
    final phone = _session!.phone;
    final token = _session!.token;

    _updateSvc(service.id, SvcState(busy: true, totalTries: service.maxTries));

    bool success   = false;
    String lastMsg = '';

    // ── MGM — Exact logic from 1Go_v1.py معاذ جلال ──────────
    if (service.actionType == ServiceActionType.mgm) {
      final rec = mgmRecord;
      if (!rec.canActivate) {
        _updateSvc(service.id, SvcState(
          result: 'fail',
          msg: '🚫 وصلت للحد الأقصى (5/5) في هذه الفترة.\nعُد بعد ${rec.daysUntilNextSlot} يوم',
        ));
        return;
      }
      final r = await _api.activateMgm(
        phone, token,
        onProgress: (attempt, total, status) {
          _updateSvc(service.id, SvcState(
            busy: true, attempt: attempt, totalTries: total,
            retryMsg: status,
          ));
        },
      );
      success  = r.ok;
      lastMsg  = r.message ?? (r.ok ? '✅ تم تفعيل 1GB MGM على شريحتك 🎉' : service.failMessage);
      if (success) { _mgmRecord = rec.addActivation(); _saveMgmRecord(); }
    }

    // ── Hack 3GB ─────────────────────────────────────────────
    else if (service.actionType == ServiceActionType.hack3gb) {
      _updateSvc(service.id, SvcState(busy: true, attempt: 1, totalTries: 2, retryMsg: 'تفعيل 2GB...'));
      final results = await _api.activate3GB(phone, token);
      final ok1 = results['2gb'] ?? false;
      final ok2 = results['1gb'] ?? false;
      success  = ok1 || ok2;
      lastMsg  = '2GB: ${ok1?"✅":"❌"}  |  1GB: ${ok2?"✅":"❌"}';
    }

    // ── Walk / Offer ──────────────────────────────────────────
    else {
      for (int i = 1; i <= service.maxTries; i++) {
        _updateSvc(service.id, SvcState(
          busy: true, attempt: i, totalTries: service.maxTries,
          retryMsg: i > 1 ? 'محاولة $i/${service.maxTries}...' : '',
        ));
        ApiResult<Map>? r;
        switch (service.actionType) {
          case ServiceActionType.walk:
            r = await _api.activateWalk(phone, token, service.packageCode!);
          case ServiceActionType.offer:
            r = await _api.activateOffer(phone, token, service.packageCode!);
          default: break;
        }
        if (r?.ok == true) { success = true; lastMsg = r?.message ?? ''; break; }
        lastMsg = r?.message ?? service.failMessage;
        if (i < service.maxTries) await Future.delayed(const Duration(milliseconds: 900));
      }
    }

    if (success) {
      _recordActivation(service.id);
      _updateSvc(service.id, SvcState(result: 'ok', msg: lastMsg.isNotEmpty ? lastMsg : '✅ تم التفعيل بنجاح'));
    } else {
      _updateSvc(service.id, SvcState(result: 'fail', msg: lastMsg.isNotEmpty ? lastMsg : service.failMessage));
    }
  }

  void _updateSvc(String id, SvcState s) { _svcStates[id] = s; notifyListeners(); }

  void _recordActivation(String serviceId) {
    final key = '${_session?.phone}:$serviceId';
    _activations[key] = (_activations[key] ?? const ActRecord()).increment();
    _saveActivations();
  }

  // ─── Recharge بالكود ──────────────────────────────────────
  Future<RechargeResult> rechargeByCode(String code) async {
    if (_session == null) return const RechargeResult(ok: false, message: 'غير مسجل الدخول');
    final r = await _api.rechargeByCode(_session!.phone, _session!.token, code);
    if (r.ok) await loadSubInfo();
    return RechargeResult(ok: r.ok, message: r.message ?? (r.ok ? '✅ تم شحن الرصيد بنجاح' : '❌ فشل الشحن — تحقق من الكود'));
  }

  // ─── Theme ────────────────────────────────────────────────
  void toggleTheme() {
    _darkMode = !_darkMode;
    _prefs.setBool('dark_mode', _darkMode);
    notifyListeners();
  }
}

// ─── Support Types ────────────────────────────────────────────────────────
class SvcState {
  final bool busy;
  final String? result;
  final String msg;
  final int attempt;
  final int totalTries;
  final String retryMsg;

  const SvcState({
    this.busy = false, this.result,
    this.msg = '', this.attempt = 0,
    this.totalTries = 1, this.retryMsg = '',
  });

  bool get isOk   => result == 'ok';
  bool get isFail => result == 'fail';
}

class RechargeResult {
  final bool ok;
  final String message;
  const RechargeResult({required this.ok, required this.message});
}
