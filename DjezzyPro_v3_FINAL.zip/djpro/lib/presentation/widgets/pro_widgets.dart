import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/theme/app_colors.dart';
import '../../data/services/djezzy_api.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — Design System Widgets                   ║
// ║   Developer: Mouad Djallel | @MouadeTEK               ║
// ╚══════════════════════════════════════════════════════════╝

// ─── Pro Card ──────────────────────────────────────────────
class ProCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final Color? color;
  final double radius;
  final VoidCallback? onTap;
  final Border? border;

  const ProCard({
    super.key,
    required this.child,
    this.padding,
    this.color,
    this.radius = 20,
    this.onTap,
    this.border,
  });

  @override
  Widget build(BuildContext context) {
    final bg = color ?? Theme.of(context).colorScheme.surface;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: padding ?? const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(radius),
          border: border ?? Border.all(color: AppColors.darkBorder, width: 1),
        ),
        child: child,
      ),
    );
  }
}

// ─── Pro Button ────────────────────────────────────────────
class ProButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool loading;
  final bool secondary;
  final IconData? icon;
  final Color? color;
  final double height;

  const ProButton({
    super.key,
    required this.label,
    this.onTap,
    this.loading = false,
    this.secondary = false,
    this.icon,
    this.color,
    this.height = 56,
  });

  @override
  Widget build(BuildContext context) {
    final bg = color ?? (secondary ? Colors.transparent : AppColors.primary);
    return SizedBox(
      height: height,
      width: double.infinity,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: loading ? null : onTap,
          borderRadius: BorderRadius.circular(16),
          child: Ink(
            decoration: BoxDecoration(
              gradient: secondary ? null : LinearGradient(
                colors: [AppColors.primaryLight, color ?? AppColors.primary, AppColors.primaryDark],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              color: secondary ? AppColors.darkSurface2 : null,
              borderRadius: BorderRadius.circular(16),
              border: secondary ? Border.all(color: AppColors.darkBorder2) : null,
              boxShadow: secondary ? null : [
                BoxShadow(
                  color: (color ?? AppColors.primary).withOpacity(0.35),
                  blurRadius: 20, offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Center(
              child: loading
                  ? SizedBox(
                      width: 22, height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: secondary ? AppColors.textPrimary : Colors.white,
                      ),
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (icon != null) ...[
                          Icon(icon, size: 20, color: secondary ? AppColors.textPrimary : Colors.white),
                          const SizedBox(width: 8),
                        ],
                        Text(
                          label,
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: secondary ? AppColors.textPrimary : Colors.white,
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Pro TextField ─────────────────────────────────────────
class ProTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final String? label;
  final IconData? prefixIcon;
  final Widget? suffix;
  final TextInputType? keyboardType;
  final bool obscure;
  final int? maxLength;
  final VoidCallback? onSubmit;
  final String? Function(String?)? validator;
  final TextInputAction? inputAction;
  final bool autofocus;

  const ProTextField({
    super.key,
    required this.controller,
    required this.hint,
    this.label,
    this.prefixIcon,
    this.suffix,
    this.keyboardType,
    this.obscure = false,
    this.maxLength,
    this.onSubmit,
    this.validator,
    this.inputAction,
    this.autofocus = false,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller:        controller,
      keyboardType:      keyboardType,
      obscureText:       obscure,
      maxLength:         maxLength,
      autofocus:         autofocus,
      textInputAction:   inputAction,
      validator:         validator,
      onFieldSubmitted:  (_) => onSubmit?.call(),
      style: const TextStyle(
        fontFamily: 'Montserrat',
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: AppColors.textPrimary,
      ),
      decoration: InputDecoration(
        hintText:      hint,
        labelText:     label,
        prefixIcon:    prefixIcon != null
            ? Icon(prefixIcon, color: AppColors.textSecondary, size: 20)
            : null,
        suffix: suffix,
        counterText:   '',
      ),
    );
  }
}

// ─── Data Progress Ring ─────────────────────────────────────
class DataRing extends StatelessWidget {
  final double percent;
  final String centerLabel;
  final String centerSub;
  final double size;

  const DataRing({
    super.key,
    required this.percent,
    required this.centerLabel,
    required this.centerSub,
    this.size = 130,
  });

  @override
  Widget build(BuildContext context) {
    final color = percent > 80 ? AppColors.error
                : percent > 55 ? AppColors.warning
                : AppColors.info;
    return SizedBox(
      width: size, height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: size, height: size,
            child: CircularProgressIndicator(
              value: percent / 100,
              strokeWidth: 10,
              strokeCap: StrokeCap.round,
              backgroundColor: AppColors.darkSurface3,
              valueColor: AlwaysStoppedAnimation(color),
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                centerLabel,
                style: const TextStyle(
                  fontFamily: 'Montserrat',
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                ),
              ),
              Text(
                centerSub,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─── Sim Tag ───────────────────────────────────────────────
class SimTag extends StatelessWidget {
  final SimType simType;
  final bool large;

  const SimTag({super.key, required this.simType, this.large = false});

  Color _color() => switch (simType) {
    SimType.zid      => AppColors.simZid,
    SimType.legend   => AppColors.simLegend,
    SimType.izzy     => AppColors.simIzzy,
    SimType.control  => AppColors.simControl,
    SimType.postpaid => AppColors.simPostpaid,
    SimType.djezzy   => AppColors.primary,
  };

  @override
  Widget build(BuildContext context) {
    final c = _color();
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: large ? 12 : 9,
        vertical:   large ? 6  : 4,
      ),
      decoration: BoxDecoration(
        color: c.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(simType.emoji, style: TextStyle(fontSize: large ? 14 : 11)),
          const SizedBox(width: 5),
          Text(
            simType.label,
            style: TextStyle(
              fontFamily: 'Montserrat',
              fontSize: large ? 12 : 10,
              fontWeight: FontWeight.w700,
              color: c,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Stat Chip ─────────────────────────────────────────────
class StatChip extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const StatChip({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) => ProCard(
    padding: const EdgeInsets.all(14),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        const SizedBox(height: 10),
        Text(value, style: TextStyle(
          fontFamily: 'Montserrat',
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: AppColors.textPrimary,
        )),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(
          fontSize: 11,
          color: AppColors.textSecondary,
        )),
      ],
    ),
  );
}

// ─── Copy Code Widget ──────────────────────────────────────
class CopyableCode extends StatefulWidget {
  final String code;
  final String description;
  final bool isFree;

  const CopyableCode({
    super.key,
    required this.code,
    required this.description,
    this.isFree = true,
  });

  @override
  State<CopyableCode> createState() => _CopyableCodeState();
}

class _CopyableCodeState extends State<CopyableCode> {
  bool _copied = false;

  void _copy() {
    Clipboard.setData(ClipboardData(text: widget.code));
    setState(() => _copied = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _copy,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _copied ? AppColors.successBg : AppColors.darkSurface2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: _copied ? AppColors.success.withOpacity(0.5) : AppColors.darkBorder,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: widget.isFree
                    ? AppColors.success.withOpacity(0.15)
                    : AppColors.error.withOpacity(0.15),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                widget.isFree ? 'FREE' : 'DA',
                style: TextStyle(
                  fontFamily: 'Montserrat',
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  color: widget.isFree ? AppColors.success : AppColors.error,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.code,
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: _copied ? AppColors.success : AppColors.primary,
                    ),
                  ),
                  Text(
                    widget.description,
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
            Icon(
              _copied ? Icons.check_circle_rounded : Icons.copy_rounded,
              size: 18,
              color: _copied ? AppColors.success : AppColors.textTertiary,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Section Header ────────────────────────────────────────
class SectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;

  const SectionHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontFamily: 'Montserrat',
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textSecondary,
                  letterSpacing: 0.8,
                ),
              ),
              if (subtitle != null)
                Text(subtitle!, style: const TextStyle(fontSize: 11, color: AppColors.textTertiary)),
            ],
          ),
        ),
        if (trailing != null) trailing!,
      ],
    ),
  );
}

// ─── Developer Badge ───────────────────────────────────────
class DeveloperBadge extends StatelessWidget {
  const DeveloperBadge({super.key});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(
      color: AppColors.darkSurface2,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: AppColors.darkBorder),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 28, height: 28,
          decoration: BoxDecoration(
            gradient: AppColors.primaryGradient,
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(Icons.code_rounded, size: 14, color: Colors.white),
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              'Mouad Djallel',
              style: TextStyle(
                fontFamily: 'Montserrat',
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            Text(
              '@MouadeTEK  •  🇩🇿',
              style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
            ),
          ],
        ),
      ],
    ),
  );
}
