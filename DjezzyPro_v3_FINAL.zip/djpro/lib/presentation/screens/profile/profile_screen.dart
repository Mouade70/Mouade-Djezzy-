import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/models/models.dart';
import '../../../data/services/djezzy_api.dart';
import '../../providers/app_provider.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — الملف الشخصي                           ║
// ║   من مطور معاذ جلال | @MouadeTEK | 🇩🇿               ║
// ╚══════════════════════════════════════════════════════════╝

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prov     = context.watch<AppProvider>();
    final session  = prov.session;
    final accounts = prov.accounts;
    final sub      = prov.subInfo;
    final mgm      = prov.mgmRecord;

    return Scaffold(
      backgroundColor: AppColors.darkBg,
      body: CustomScrollView(slivers: [
        // ── AppBar ─────────────────────────────────────────────
        SliverAppBar(
          pinned: true,
          backgroundColor: AppColors.darkBg,
          elevation: 0,
          expandedHeight: 0,
          title: const Text('الملف الشخصي',
            style: TextStyle(fontFamily:'Montserrat',fontWeight:FontWeight.w800,fontSize:20,color:AppColors.textPrimary)),
          actions: [
            IconButton(
              icon: const Icon(Icons.brightness_6_rounded, color: AppColors.textSecondary),
              onPressed: prov.toggleTheme,
            ),
          ],
        ),

        SliverPadding(padding: const EdgeInsets.all(16), sliver: SliverList(delegate: SliverChildListDelegate([

          // ── Active Account Hero ─────────────────────────────────
          if (session != null) ...[
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: AppColors.balanceGradient,
                borderRadius: BorderRadius.circular(22),
                boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.3), blurRadius: 20, offset: const Offset(0,8))],
              ),
              child: Row(children: [
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), shape: BoxShape.circle),
                  child: Center(child: Text(sub.simType.emoji, style: const TextStyle(fontSize: 26))),
                ),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('الحساب النشط', style: TextStyle(fontFamily:'Montserrat',fontSize:10,color:Colors.white70,letterSpacing:1.5)),
                  const SizedBox(height: 3),
                  Text(maskPhone(session.phone),
                    style: const TextStyle(fontFamily:'Montserrat',fontSize:18,fontWeight:FontWeight.w800,color:Colors.white)),
                  Text(sub.simType.label, style: const TextStyle(fontSize:12,color:Colors.white70)),
                ])),
                Container(
                  width: 10, height: 10,
                  decoration: BoxDecoration(color: AppColors.success, shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: AppColors.success.withOpacity(0.5), blurRadius: 8)]),
                ),
              ]),
            ),
            const SizedBox(height: 12),
          ],

          // ── MGM Counter ──────────────────────────────────────────
          ProCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionHeader(title: 'عداد MGM — كل 16 يوم'),
            Row(children: [
              ...List.generate(5, (i) => Expanded(
                child: Container(
                  margin: const EdgeInsets.only(right: 6),
                  height: 8,
                  decoration: BoxDecoration(
                    color: i < mgm.countInPeriod ? AppColors.info : AppColors.darkSurface3,
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: i < mgm.countInPeriod ? [BoxShadow(color: AppColors.info.withOpacity(0.4), blurRadius: 6)] : null,
                  ),
                ),
              )),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Text('${mgm.countInPeriod}/5 مستخدم',
                style: const TextStyle(fontFamily:'Montserrat',fontSize:13,fontWeight:FontWeight.w700,color:AppColors.textPrimary)),
              const Spacer(),
              if (!mgm.canActivate)
                Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:4),
                  decoration:BoxDecoration(color:AppColors.warningBg,borderRadius:BorderRadius.circular(8)),
                  child:Text('يُجدَّد خلال ${mgm.daysUntilNextSlot} يوم',
                    style:const TextStyle(fontFamily:'Montserrat',fontSize:11,color:AppColors.warning,fontWeight:FontWeight.w600)))
              else
                Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:4),
                  decoration:BoxDecoration(color:AppColors.successBg,borderRadius:BorderRadius.circular(8)),
                  child:const Text('متاح للتفعيل',
                    style:TextStyle(fontFamily:'Montserrat',fontSize:11,color:AppColors.success,fontWeight:FontWeight.w600))),
            ]),
          ])),
          const SizedBox(height: 12),

          // ── Other Accounts ────────────────────────────────────────
          if (accounts.length > 1) ...[
            const SectionHeader(title: 'الحسابات المحفوظة'),
            ...accounts.where((a) => a.phone != session?.phone).map((acc) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: GestureDetector(
                onTap: () => prov.switchAccount(acc),
                child: ProCard(padding: const EdgeInsets.all(14), child: Row(children: [
                  Container(width:46,height:46,
                    decoration:BoxDecoration(color:Color(acc.simType.color).withOpacity(0.12),borderRadius:BorderRadius.circular(14)),
                    child:Center(child:Text(acc.simType.emoji,style:const TextStyle(fontSize:22)))),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(acc.displayLabel,style:const TextStyle(fontFamily:'Montserrat',fontSize:14,fontWeight:FontWeight.w700,color:AppColors.textPrimary)),
                    Text(maskPhone(acc.phone),style:const TextStyle(fontSize:12,color:AppColors.textSecondary)),
                  ])),
                  SimTag(simType: acc.simType),
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.delete_outline_rounded, color: AppColors.error, size: 20),
                    onPressed: () => _confirmDelete(context, prov, acc),
                  ),
                ])),
              ),
            )),
            const SizedBox(height: 4),
          ],

          // ── Add New Account ───────────────────────────────────────
          ProButton(
            label: 'إضافة رقم جديد',
            icon: Icons.add_rounded,
            secondary: true,
            onTap: () => Navigator.pushNamed(context, '/auth'),
          ),
          const SizedBox(height: 12),

          // ── Settings ─────────────────────────────────────────────
          const SectionHeader(title: 'الإعدادات'),
          ProCard(child: Column(children: [
            _row(Icons.brightness_6_rounded, 'الوضع الداكن / الفاتح', AppColors.info, onTap: prov.toggleTheme),
            const Divider(color: AppColors.darkBorder, height: 1),
            _row(Icons.info_outline_rounded, 'حول التطبيق', Color(0xFF8B5CF6), onTap: () => Navigator.pushNamed(context, '/about')),
            const Divider(color: AppColors.darkBorder, height: 1),
            _row(Icons.share_rounded, 'مشاركة التطبيق', AppColors.success, onTap: () {}),
          ])),
          const SizedBox(height: 12),

          // ── Logout ────────────────────────────────────────────────
          GestureDetector(
            onTap: () => _confirmLogout(context, prov),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                color: AppColors.errorBg,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.error.withOpacity(0.3)),
              ),
              child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.logout_rounded, color: AppColors.error, size: 20),
                SizedBox(width: 10),
                Text('تسجيل الخروج', style: TextStyle(fontFamily:'Montserrat',fontSize:15,fontWeight:FontWeight.w700,color:AppColors.error)),
              ]),
            ),
          ),
          const SizedBox(height: 20),

          // ── Footer ────────────────────────────────────────────────
          const DeveloperBadge(),
          const SizedBox(height: 8),
          const Center(child: Text(
            'Djezzy Pro v3.0\nمن مطور معاذ جلال | @MouadeTEK | 🇩🇿',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 10, color: AppColors.textTertiary, fontFamily: 'Montserrat', height: 1.6),
          )),
          const SizedBox(height: 24),

        ]))),
      ]),
    );
  }

  Widget _row(IconData icon, String label, Color c, {required VoidCallback onTap}) =>
      ListTile(
        onTap: onTap,
        leading: Container(width:38,height:38,decoration:BoxDecoration(color:c.withOpacity(0.15),borderRadius:BorderRadius.circular(11)),child:Icon(icon,color:c,size:20)),
        title: Text(label, style: const TextStyle(fontFamily:'Montserrat',fontSize:14,fontWeight:FontWeight.w600,color:AppColors.textPrimary)),
        trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textTertiary, size: 20),
        contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      );

  void _confirmLogout(BuildContext context, AppProvider prov) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: AppColors.darkSurface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('تسجيل الخروج', style: TextStyle(fontFamily:'Montserrat',fontWeight:FontWeight.w700)),
      content: const Text('هل أنت متأكد من تسجيل الخروج؟', style: TextStyle(color:AppColors.textSecondary)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء', style: TextStyle(color:AppColors.textSecondary))),
        TextButton(onPressed: () { Navigator.pop(context); prov.logout(); Navigator.pushNamedAndRemoveUntil(context, '/auth', (_) => false); },
          child: const Text('تسجيل الخروج', style: TextStyle(color:AppColors.error,fontFamily:'Montserrat',fontWeight:FontWeight.w700))),
      ],
    ));
  }

  void _confirmDelete(BuildContext context, AppProvider prov, AccountModel acc) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: AppColors.darkSurface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('حذف الحساب', style: TextStyle(fontFamily:'Montserrat',fontWeight:FontWeight.w700)),
      content: Text('حذف ${maskPhone(acc.phone)}؟', style: const TextStyle(color:AppColors.textSecondary)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء', style: TextStyle(color:AppColors.textSecondary))),
        TextButton(onPressed: () { Navigator.pop(context); prov.deleteAccount(acc.phone); },
          child: const Text('حذف', style: TextStyle(color:AppColors.error,fontFamily:'Montserrat',fontWeight:FontWeight.w700))),
      ],
    ));
  }
}
