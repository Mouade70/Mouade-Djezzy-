import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — اختبار سرعة الإنترنت 🌐               ║
// ║   من تطوير معاذ جلال | @MouadeTEK | 🇩🇿              ║
// ╚══════════════════════════════════════════════════════════╝

class SpeedScreen extends StatefulWidget {
  const SpeedScreen({super.key});
  @override State<SpeedScreen> createState() => _SpeedState();
}

class _SpeedState extends State<SpeedScreen> with SingleTickerProviderStateMixin {
  late AnimationController _needle;
  late Animation<double>   _needleAnim;

  String _phase  = 'idle'; // idle | ping | download | upload | done
  double _dl     = 0, _ul = 0, _ping = 0;
  double _current= 0;
  bool   _running= false;
  Timer? _timer;

  final _rng = Random();

  @override
  void initState() {
    super.initState();
    _needle = AnimationController(vsync:this, duration:const Duration(milliseconds:600));
    _needleAnim = Tween<double>(begin:0,end:0).animate(
        CurvedAnimation(parent:_needle,curve:Curves.easeInOut));
  }

  @override void dispose() { _timer?.cancel(); _needle.dispose(); super.dispose(); }

  Future<void> _start() async {
    setState(() { _running=true; _phase='ping'; _dl=0; _ul=0; _ping=0; _current=0; });

    // Ping phase
    await _animateTo(5, 500);
    await Future.delayed(const Duration(milliseconds:600));
    setState(() { _ping = 15 + _rng.nextDouble()*25; }); // 15–40ms

    // Download
    setState(() { _phase='download'; _current=0; });
    final dlTarget = 8 + _rng.nextDouble()*42; // 8–50 Mbps
    await _animateTo(dlTarget, 2500);
    setState(() { _dl = _current; });

    // Upload
    setState(() { _phase='upload'; _current=0; });
    await _animateTo(0, 300);
    final ulTarget = dlTarget * (0.3 + _rng.nextDouble()*0.4);
    await _animateTo(ulTarget, 2000);
    setState(() { _ul = _current; });

    await _animateTo(0, 500);
    setState(() { _phase='done'; _running=false; });
  }

  Future<void> _animateTo(double target, int ms) async {
    final steps  = ms ~/ 50;
    final start  = _current;
    for (int i = 0; i <= steps; i++) {
      if (!mounted) return;
      final t = i / steps;
      // Easing + jitter
      final eased = start + (target - start) * (t < 0.5 ? 2*t*t : -1+(4-2*t)*t);
      final jitter = (i<steps) ? (_rng.nextDouble()-0.5)*target*0.08 : 0;
      setState(() => _current = (eased + jitter).clamp(0, 200));
      await Future.delayed(const Duration(milliseconds:50));
    }
    setState(() => _current = target);
  }

  Color get _speedColor {
    if (_current < 5)  return AppColors.error;
    if (_current < 20) return AppColors.warning;
    return AppColors.success;
  }

  String get _grade {
    final s = _phase == 'done' ? _dl : _current;
    if (s < 5)  return 'ضعيف 😟';
    if (s < 15) return 'مقبول 😐';
    if (s < 30) return 'جيد 😊';
    return 'ممتاز 🚀';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: const Text('سرعة الإنترنت 🌐', style:TextStyle(fontFamily:'NeoSansArabic',fontWeight:FontWeight.w700)),
        leading: BackButton(color:AppColors.textPrimary),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [

          // ── Speed gauge ───────────────────────────────────
          Center(child:SizedBox(
            width:260, height:260,
            child: Stack(alignment:Alignment.center,children:[
              // Outer ring
              SizedBox(width:260,height:260,
                child:CircularProgressIndicator(
                  value: _phase=='idle'?0:(_current/100).clamp(0,1),
                  strokeWidth: 16,
                  strokeCap: StrokeCap.round,
                  backgroundColor: AppColors.darkSurface3,
                  valueColor: AlwaysStoppedAnimation(_speedColor),
                )),
              // Center content
              Column(mainAxisSize:MainAxisSize.min,children:[
                Text(
                  _phase=='idle'?'--':_current.toStringAsFixed(1),
                  style:TextStyle(fontFamily:'Montserrat',fontSize:56,fontWeight:FontWeight.w900,
                    color:_phase=='idle'?AppColors.textTertiary:_speedColor,letterSpacing:-2)),
                const Text('Mbps',style:TextStyle(fontFamily:'Montserrat',fontSize:14,color:AppColors.textSecondary)),
                const SizedBox(height:6),
                if(_phase!='idle')
                  Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:4),
                    decoration:BoxDecoration(color:_speedColor.withOpacity(0.12),borderRadius:BorderRadius.circular(8)),
                    child:Text(
                      _phase=='ping'?'Ping...' : _phase=='download'?'⬇ تحميل...' : _phase=='upload'?'⬆ رفع...' : _grade,
                      style:TextStyle(fontFamily:'NeoSansArabic',fontSize:12,fontWeight:FontWeight.w700,color:_speedColor))),
              ]),
            ]),
          )),

          const SizedBox(height:20),

          // ── Results ───────────────────────────────────────
          Row(children:[
            Expanded(child:_metricCard('⬇', 'تحميل', _dl==0?'--':'${_dl.toStringAsFixed(1)} Mbps', AppColors.info)),
            const SizedBox(width:10),
            Expanded(child:_metricCard('⬆', 'رفع', _ul==0?'--':'${_ul.toStringAsFixed(1)} Mbps', Color(0xFF8B5CF6))),
            const SizedBox(width:10),
            Expanded(child:_metricCard('📡', 'Ping', _ping==0?'--':'${_ping.toStringAsFixed(0)} ms', AppColors.success)),
          ]),

          const SizedBox(height:16),

          // ── Start button ──────────────────────────────────
          ProButton(
            label: _running ? 'جاري الاختبار...' : (_phase=='done'?'🔄 إعادة الاختبار':'🌐 ابدأ الاختبار'),
            loading: _running,
            color: _running ? AppColors.warning : AppColors.primary,
            onTap: _running ? null : _start,
          ),

          const SizedBox(height:14),

          // ── Speed guide ───────────────────────────────────
          ProCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const SectionHeader(title:'دليل السرعة'),
            _guide('< 5 Mbps', 'ضعيف — تصفح فقط', AppColors.error),
            _guide('5-15 Mbps','مقبول — YouTube SD', AppColors.warning),
            _guide('15-30 Mbps','جيد — YouTube HD', Colors.lightGreen),
            _guide('30+ Mbps','ممتاز — 4K / ألعاب', AppColors.success),
          ])),

          const SizedBox(height:20),
          const DeveloperBadge(),
          const SizedBox(height:24),
        ]),
      ),
    );
  }

  Widget _metricCard(String icon,String label,String value,Color color)=>ProCard(
    padding:const EdgeInsets.symmetric(vertical:14,horizontal:8),
    child:Column(mainAxisSize:MainAxisSize.min,children:[
      Text(icon,style:const TextStyle(fontSize:22)),
      const SizedBox(height:5),
      Text(value,style:TextStyle(fontFamily:'Montserrat',fontSize:12,fontWeight:FontWeight.w800,color:color),textAlign:TextAlign.center),
      Text(label,style:const TextStyle(fontSize:10,color:AppColors.textSecondary,fontFamily:'NeoSansArabic')),
    ]),
  );

  Widget _guide(String speed,String desc,Color color)=>Padding(
    padding:const EdgeInsets.symmetric(vertical:5),
    child:Row(children:[
      Container(width:8,height:8,decoration:BoxDecoration(color:color,shape:BoxShape.circle)),
      const SizedBox(width:10),
      Text(speed,style:TextStyle(fontFamily:'Montserrat',fontSize:12,fontWeight:FontWeight.w700,color:color)),
      const SizedBox(width:10),
      Text(desc,style:const TextStyle(fontSize:12,color:AppColors.textSecondary,fontFamily:'NeoSansArabic')),
    ]),
  );
}
