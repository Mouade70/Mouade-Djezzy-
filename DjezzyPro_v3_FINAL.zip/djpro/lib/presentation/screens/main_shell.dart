import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import 'home/home_screen.dart';
import 'services/services_screen.dart';
import 'ussd/ussd_screen.dart';
import 'profile/profile_screen.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — الشريط السفلي للتنقل                   ║
// ║   من تطوير معاذ جلال | @MouadeTEK | 🇩🇿              ║
// ╚══════════════════════════════════════════════════════════╝

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _idx = 0;
  static const _screens = [
    HomeScreen(),
    ServicesScreen(),
    UssdScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.darkBg,
    body: IndexedStack(index: _idx, children: _screens),
    bottomNavigationBar: _BottomNav(idx: _idx, onTap: (i) => setState(() => _idx = i)),
  );
}

class _BottomNav extends StatelessWidget {
  final int idx;
  final void Function(int) onTap;
  const _BottomNav({required this.idx, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.home_rounded,          Icons.home_outlined,           'الرئيسية'),
      (Icons.bolt_rounded,           Icons.bolt_outlined,            'الخدمات'),
      (Icons.dialpad_rounded,        Icons.dialpad_outlined,         'USSD'),
      (Icons.person_rounded,         Icons.person_outlined,          'حسابي'),
    ];
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.darkSurface,
        border: Border(top: BorderSide(color: AppColors.darkBorder, width: 0.5)),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Row(
            children: List.generate(items.length, (i) {
              final sel = idx == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () => onTap(i),
                  behavior: HitTestBehavior.opaque,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      color: sel ? AppColors.primary.withOpacity(0.1) : Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(
                        sel ? items[i].$1 : items[i].$2,
                        color: sel ? AppColors.primary : AppColors.textTertiary,
                        size: sel ? 26 : 23,
                      ),
                      const SizedBox(height: 3),
                      Text(items[i].$3, style: TextStyle(
                        fontFamily: 'NeoSansArabic',
                        fontSize: 10,
                        fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                        color: sel ? AppColors.primary : AppColors.textTertiary,
                      )),
                      if (sel) ...[
                        const SizedBox(height: 3),
                        Container(width: 16, height: 3,
                          decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(2))),
                      ],
                    ]),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
