import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../../../core/theme/app_colors.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — معلومات الشبكة 📡                     ║
// ║   من تطوير معاذ جلال | @MouadeTEK | 🇩🇿              ║
// ╚══════════════════════════════════════════════════════════╝

class NetworkScreen extends StatefulWidget {
  const NetworkScreen({super.key});
  @override State<NetworkScreen> createState() => _NetState();
}

class _NetState extends State<NetworkScreen> {
  String _connType = '---';
  bool   _loading  = false;

  @override
  void initState() { super.initState(); _check(); }

  Future<void> _check() async {
    setState(() => _loading = true);
    try {
      final r = await Connectivity().checkConnectivity();
      setState(() {
        _connType = switch (r.first) {
          ConnectivityResult.mobile => 'بيانات الهاتف (4G/5G)',
          ConnectivityResult.wifi   => 'Wi-Fi',
          ConnectivityResult.none   => 'لا يوجد اتصال',
          _                        => 'غير معروف',
        };
      });
    } catch (_) { setState(() => _connType = 'تعذّر الفحص'); }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: const Text('الشبكة والتغطية 📡', style:TextStyle(fontFamily:'NeoSansArabic',fontWeight:FontWeight.w700)),
        leading: BackButton(color:AppColors.textPrimary),
        actions:[IconButton(icon:const Icon(Icons.refresh_rounded,color:AppColors.primary),onPressed:_check)],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children:[

          // ── Network status ─────────────────────────────
          ProCard(
            child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              const SectionHeader(title:'حالة الاتصال الآن'),
              Row(children:[
                Container(width:50,height:50,
                  decoration:BoxDecoration(color:AppColors.success.withOpacity(0.12),borderRadius:BorderRadius.circular(14)),
                  child:const Icon(Icons.signal_cellular_alt_rounded,color:AppColors.success,size:26)),
                const SizedBox(width:14),
                Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                  Text(_connType,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:16,fontWeight:FontWeight.w700,color:AppColors.textPrimary)),
                  const Text('Djezzy Algeria 🇩🇿',style:TextStyle(fontSize:12,color:AppColors.textSecondary)),
                ])),
                if(_loading) const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2,color:AppColors.primary))
                else Container(width:12,height:12,decoration:BoxDecoration(color:AppColors.success,shape:BoxShape.circle,
                  boxShadow:[BoxShadow(color:AppColors.success.withOpacity(0.5),blurRadius:6)])),
              ]),
            ]),
          ),

          const SizedBox(height:12),

          // ── Technology ────────────────────────────────
          ProCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const SectionHeader(title:'تقنيات Djezzy'),
            ...[
              _NetTech('5G',      'مدن رئيسية',          '28 GHz / 3.5 GHz', AppColors.primary,       true),
              _NetTech('4G LTE',  'تغطية وطنية 85%',     '800 MHz / 1800 MHz / 2600 MHz', AppColors.info,   true),
              _NetTech('3G HSPA+','مناطق نائية',          '2100 MHz', Color(0xFF8B5CF6),                false),
              _NetTech('2G EDGE', 'أماكن بعيدة جداً',    '900 MHz', AppColors.textTertiary,             false),
            ].map((t)=>Padding(
              padding:const EdgeInsets.only(bottom:10),
              child:Row(children:[
                Container(
                  width:52,
                  padding:const EdgeInsets.symmetric(vertical:5),
                  decoration:BoxDecoration(color:t.color.withOpacity(0.15),borderRadius:BorderRadius.circular(8)),
                  child:Text(t.gen,style:TextStyle(fontFamily:'Montserrat',fontSize:12,fontWeight:FontWeight.w800,color:t.color),textAlign:TextAlign.center)),
                const SizedBox(width:12),
                Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                  Text(t.coverage,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:13,fontWeight:FontWeight.w600,color:AppColors.textPrimary)),
                  Text(t.freq,style:const TextStyle(fontSize:10,color:AppColors.textSecondary,fontFamily:'Montserrat')),
                ])),
                if(t.active)
                  Container(width:8,height:8,decoration:BoxDecoration(color:t.color,shape:BoxShape.circle,
                    boxShadow:[BoxShadow(color:t.color.withOpacity(0.5),blurRadius:5)])),
              ]),
            )),
          ])),

          const SizedBox(height:12),

          // ── 5G cities ────────────────────────────────
          ProCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const SectionHeader(title:'مدن التغطية 5G'),
            Wrap(spacing:8,runSpacing:8,children:[
              'الجزائر العاصمة','وهران','قسنطينة','عنابة','سطيف','بجاية','تيزي وزو','البليدة','بومرداس','تيبازة',
            ].map((city)=>Container(
              padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),
              decoration:BoxDecoration(
                color:AppColors.primary.withOpacity(0.1),
                borderRadius:BorderRadius.circular(20),
                border:Border.all(color:AppColors.primary.withOpacity(0.3))),
              child:Row(mainAxisSize:MainAxisSize.min,children:[
                Container(width:6,height:6,decoration:BoxDecoration(color:AppColors.primary,shape:BoxShape.circle)),
                const SizedBox(width:6),
                Text(city,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:12,color:AppColors.primary,fontWeight:FontWeight.w600)),
              ]),
            )).toList(),
          ])),

          const SizedBox(height:12),

          // ── Tips ─────────────────────────────────────
          ProCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const SectionHeader(title:'نصائح لأفضل اتصال'),
            ...[
              ('📍','في الخارج أحسن من الداخل'),
              ('🔄','أعد تشغيل الهاتف لتحديث الشبكة'),
              ('✈️','أوقف وضع الطيران ثم أعده'),
              ('📶','اختر يدوياً Djezzy 5G في الإعدادات'),
            ].map((t)=>Padding(
              padding:const EdgeInsets.symmetric(vertical:5),
              child:Row(children:[
                Text(t.$1,style:const TextStyle(fontSize:16)),
                const SizedBox(width:10),
                Text(t.$2,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:12,color:AppColors.textSecondary)),
              ]),
            )),
          ])),

          const SizedBox(height:20),
          const DeveloperBadge(),
          const SizedBox(height:24),
        ]),
      ),
    );
  }
}

class _NetTech {
  final String gen,coverage,freq; final Color color; final bool active;
  const _NetTech(this.gen,this.coverage,this.freq,this.color,this.active);
}
