import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/constants/api_constants.dart';
import '../../../data/models/service_model.dart';
import '../../providers/app_provider.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — شاشة MGM (5 تفعيلات كل 16 يوم)       ║
// ║   الخوارزمية مأخوذة من 1Go_v1.py معاذ جلال           ║
// ║   من مطور معاذ جلال | @MouadeTEK | 🇩🇿               ║
// ╚══════════════════════════════════════════════════════════╝

class MgmScreen extends StatelessWidget {
  const MgmScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prov     = context.watch<AppProvider>();
    final mgm      = prov.mgmRecord;
    final canAct   = mgm.canActivate;
    final used     = mgm.countInPeriod;
    final svcState = prov.svcState('mgm');
    final mgmSvc   = allServices.firstWhere((s) => s.id == 'mgm');

    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: const Text('MGM 1GB'),
        leading: BackButton(color: AppColors.textPrimary),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.info.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.info.withOpacity(0.3)),
            ),
            child: Text(
              '$used / ${ApiConstants.mgmMaxPerPeriod}',
              style: const TextStyle(fontFamily:'Montserrat',fontSize:14,fontWeight:FontWeight.w800,color:AppColors.info),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [

          // ── Hero Card ─────────────────────────────────────────
          ProCard(child: Column(children: [
            Container(
              width: 80, height: 80,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.info.withOpacity(0.3), AppColors.info.withOpacity(0.08)]),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.info.withOpacity(0.3), width: 1.5),
              ),
              child: const Icon(Icons.people_alt_rounded, size: 40, color: AppColors.info),
            ),
            const SizedBox(height: 16),
            const Text('ادعُ صديقاً — احصل على 1GB',
              style: TextStyle(fontFamily:'Montserrat',fontSize:20,fontWeight:FontWeight.w800,color:AppColors.textPrimary,letterSpacing:-0.5)),
            const SizedBox(height: 8),
            const Text(
              'يُولِّد التطبيق أرقام جيزي عشوائية تلقائياً\nكما في خوارزمية 1Go_v1.py الأصلية',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize:13,color:AppColors.textSecondary,height:1.5),
            ),
          ])),
          const SizedBox(height: 12),

          // ── 16-Day Limit Tracker ──────────────────────────────
          ProCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('LIMITE MENSUELLE', style: TextStyle(fontFamily:'Montserrat',fontSize:10,fontWeight:FontWeight.w700,color:AppColors.textSecondary,letterSpacing:2)),
                SizedBox(height: 2),
                Text('5 تفعيلات كل 16 يوم', style: TextStyle(fontSize:12,color:AppColors.textTertiary)),
              ])),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: canAct ? AppColors.successBg : AppColors.warningBg,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  canAct ? 'متاح' : 'محدود',
                  style: TextStyle(fontFamily:'Montserrat',fontSize:11,fontWeight:FontWeight.w700,
                    color: canAct ? AppColors.success : AppColors.warning),
                ),
              ),
            ]),
            const SizedBox(height: 14),
            Row(children: List.generate(ApiConstants.mgmMaxPerPeriod, (i) => Expanded(
              child: Container(
                margin: EdgeInsets.only(right: i < ApiConstants.mgmMaxPerPeriod-1 ? 7 : 0),
                height: 8,
                decoration: BoxDecoration(
                  color: i < used ? AppColors.info : AppColors.darkSurface3,
                  borderRadius: BorderRadius.circular(4),
                  boxShadow: i < used ? [BoxShadow(color: AppColors.info.withOpacity(0.4), blurRadius: 6)] : null,
                ),
              ),
            ))),
            const SizedBox(height: 10),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('$used / ${ApiConstants.mgmMaxPerPeriod} مستخدم',
                style: const TextStyle(fontFamily:'Montserrat',fontSize:14,fontWeight:FontWeight.w700,color:AppColors.textPrimary)),
              if (!canAct)
                Text('يُجدَّد خلال ${mgm.daysUntilNextSlot} يوم',
                  style: const TextStyle(fontFamily:'Montserrat',fontSize:12,color:AppColors.warning,fontWeight:FontWeight.w600)),
            ]),
          ])),
          const SizedBox(height: 12),

          // ── Progress ──────────────────────────────────────────
          if (svcState.busy) ...[
            ProCard(child: Column(children: [
              Row(children: [
                SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2.5,color:AppColors.info)),
                const SizedBox(width: 12),
                Expanded(child: Text(
                  svcState.retryMsg.isNotEmpty ? svcState.retryMsg : 'جاري البحث...',
                  style: const TextStyle(fontFamily:'Montserrat',fontSize:14,fontWeight:FontWeight.w600,color:AppColors.textPrimary),
                )),
              ]),
              const SizedBox(height: 12),
              ClipRRect(borderRadius: BorderRadius.circular(4), child:
                LinearProgressIndicator(
                  value: svcState.totalTries > 0 ? svcState.attempt / svcState.totalTries : null,
                  backgroundColor: AppColors.darkSurface3,
                  valueColor: const AlwaysStoppedAnimation(AppColors.info),
                  minHeight: 5,
                )),
              const SizedBox(height: 6),
              Text('المحاولة ${svcState.attempt} / ${svcState.totalTries}',
                style: const TextStyle(fontSize:11,color:AppColors.textSecondary)),
            ])),
            const SizedBox(height: 12),
          ],

          // ── Result ────────────────────────────────────────────
          if (svcState.isOk) ...[
            ProCard(
              color: AppColors.successBg,
              border: Border.all(color: AppColors.success.withOpacity(0.4)),
              child: Row(children: [
                const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 24),
                const SizedBox(width: 12),
                Expanded(child: Text(svcState.msg,
                  style: const TextStyle(fontFamily:'Montserrat',fontSize:14,fontWeight:FontWeight.w600,color:AppColors.success))),
              ]),
            ),
            const SizedBox(height: 12),
          ],

          if (svcState.isFail) ...[
            ProCard(
              color: AppColors.errorBg,
              border: Border.all(color: AppColors.error.withOpacity(0.4)),
              child: Row(children: [
                const Icon(Icons.error_rounded, color: AppColors.error, size: 24),
                const SizedBox(width: 12),
                Expanded(child: Text(svcState.msg, style: const TextStyle(fontSize:13,color:AppColors.error,height:1.4))),
              ]),
            ),
            const SizedBox(height: 12),
          ],

          // ── Action ────────────────────────────────────────────
          if (!canAct)
            ProCard(
              color: AppColors.warningBg,
              border: Border.all(color: AppColors.warning.withOpacity(0.3)),
              child: Column(children: [
                const Icon(Icons.lock_clock_rounded, color: AppColors.warning, size: 44),
                const SizedBox(height: 12),
                Text('الحد الأقصى (${ApiConstants.mgmMaxPerPeriod}/${ApiConstants.mgmMaxPerPeriod})',
                  style: const TextStyle(fontFamily:'Montserrat',fontSize:16,fontWeight:FontWeight.w700,color:AppColors.warning)),
                const SizedBox(height: 6),
                Text('عُد بعد ${mgm.daysUntilNextSlot} يوم',
                  style: const TextStyle(fontSize:13,color:AppColors.textSecondary)),
              ]),
            )
          else
            ProButton(
              label: svcState.busy ? 'جاري التفعيل...' : '🤝  تفعيل MGM 1GB',
              loading: svcState.busy,
              onTap: svcState.busy ? null : () => context.read<AppProvider>().activateService(mgmSvc),
            ),

          const SizedBox(height: 20),

          // ── How it works ──────────────────────────────────────
          const SectionHeader(title: 'كيف يعمل — الخوارزمية الأصلية'),
          ProCard(child: Column(children: [
            _step('1', 'يُولِّد التطبيق رقم جيزي عشوائي (077/078/079)', AppColors.info),
            _step('2', 'يُرسل دعوة MGM للرقم العشوائي', AppColors.success),
            _step('3', 'يُسجّل الرقم العشوائي في الشبكة', AppColors.warning),
            _step('4', 'ينتظر ثانيتين ثم يُفعِّل المكافأة', AppColors.primary),
            _step('5', 'يُكرِّر حتى 50 مرة أو النجاح', Color(0xFF8B5CF6)),
          ])),
          const SizedBox(height: 20),

          const DeveloperBadge(),
          const SizedBox(height: 8),
          const Center(child: Text('الخوارزمية من 1Go_v1.py | من مطور معاذ جلال 🇩🇿',
            style: TextStyle(fontSize:10,color:AppColors.textTertiary,fontFamily:'Montserrat'))),
          const SizedBox(height: 20),
        ]),
      ),
    );
  }

  Widget _step(String num, String text, Color c) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(children: [
      Container(width:28,height:28,decoration:BoxDecoration(color:c.withOpacity(0.15),shape:BoxShape.circle),
        child:Center(child:Text(num,style:TextStyle(fontFamily:'Montserrat',fontSize:13,fontWeight:FontWeight.w800,color:c)))),
      const SizedBox(width: 12),
      Expanded(child:Text(text,style:const TextStyle(fontSize:13,color:AppColors.textSecondary,height:1.4))),
    ]),
  );
}
