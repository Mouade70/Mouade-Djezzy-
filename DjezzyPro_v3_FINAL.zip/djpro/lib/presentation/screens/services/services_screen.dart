// ════════════════════════════════════════════════════════════
// services_screen.dart
// ════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/models/service_model.dart';
import '../../providers/app_provider.dart';
import '../../widgets/pro_widgets.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});
  @override State<ServicesScreen> createState() => _ServicesState();
}

class _ServicesState extends State<ServicesScreen> with SingleTickerProviderStateMixin {
  late TabController _tab;
  @override void initState() { super.initState(); _tab = TabController(length: 3, vsync: this); }
  @override void dispose() { _tab.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<AppProvider>();
    final tabs = [
      ('🆓 Gratuit', allServices.where((s) => s.category == ServiceCategory.free).toList()),
      ('💰 Payant',  allServices.where((s) => s.category == ServiceCategory.paid).toList()),
      ('🎛 Contrôle',allServices.where((s) => s.category == ServiceCategory.control).toList()),
    ];

    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: const Text('Services'),
        bottom: TabBar(
          controller: _tab,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textTertiary,
          indicatorColor: AppColors.primary,
          indicatorSize: TabBarIndicatorSize.label,
          labelStyle: const TextStyle(fontFamily: 'Montserrat', fontSize: 12, fontWeight: FontWeight.w700),
          tabs: tabs.map((t) => Tab(text: t.$1)).toList(),
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: tabs.map((t) => _ServiceList(services: t.$2, prov: prov)).toList(),
      ),
    );
  }
}

class _ServiceList extends StatelessWidget {
  final List<DjezzyService> services;
  final AppProvider prov;
  const _ServiceList({required this.services, required this.prov});

  @override
  Widget build(BuildContext context) => ListView.separated(
    padding: const EdgeInsets.all(16),
    itemCount: services.length,
    separatorBuilder: (_, __) => const SizedBox(height: 10),
    itemBuilder: (_, i) {
      final s = services[i];
      final st = prov.svcState(s.id);
      final rec = prov.activationRecord(s.id);
      final incompatible = s.requiredSim != null && s.requiredSim != prov.subInfo.simType;
      return _ServiceCard(svc: s, state: st, record: rec, incompatible: incompatible, onActivate: () => prov.activateService(s));
    },
  );
}

class _ServiceCard extends StatelessWidget {
  final DjezzyService svc;
  final SvcState state;
  final ActRecord record;
  final bool incompatible;
  final VoidCallback onActivate;

  const _ServiceCard({required this.svc, required this.state, required this.record, required this.incompatible, required this.onActivate});

  @override
  Widget build(BuildContext context) {
    final c = svc.color;
    return Container(
      decoration: BoxDecoration(
        color: AppColors.darkSurface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: state.isOk ? AppColors.success.withOpacity(0.4)
               : state.isFail ? AppColors.error.withOpacity(0.3)
               : AppColors.darkBorder,
        ),
      ),
      child: Column(
        children: [
          // Color strip
          Container(height: 3, decoration: BoxDecoration(
            gradient: LinearGradient(colors: [c, c.withOpacity(0.4)]),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          )),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(children: [
                  Container(width: 48, height: 48,
                    decoration: BoxDecoration(color: c.withOpacity(0.12), borderRadius: BorderRadius.circular(14)),
                    child: Icon(svc.icon, color: c, size: 24)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Text(svc.name, style: const TextStyle(fontFamily: 'Montserrat', fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                      if (svc.badge != null) ...[
                        const SizedBox(width: 6),
                        Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.2), borderRadius: BorderRadius.circular(5)),
                          child: Text(svc.badge!, style: const TextStyle(fontFamily: 'Montserrat', fontSize: 9, fontWeight: FontWeight.w800, color: AppColors.primary))),
                      ],
                      if (svc.price > 0) ...[
                        const SizedBox(width: 6),
                        Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(color: c.withOpacity(0.15), borderRadius: BorderRadius.circular(5)),
                          child: Text('${svc.price} DA', style: TextStyle(fontFamily: 'Montserrat', fontSize: 9, fontWeight: FontWeight.w700, color: c))),
                      ],
                    ]),
                    Text(svc.subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  ])),
                ]),
                const SizedBox(height: 10),
                // Chips
                Wrap(spacing: 7, children: [
                  _chip('📦 ${svc.data}'),
                  _chip('⏱ ${svc.validity}'),
                  if (svc.requiredSim != null) SimTag(simType: svc.requiredSim!),
                ]),
                // Last activation
                if (record.count > 0) ...[
                  const SizedBox(height: 8),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(color: AppColors.darkSurface2, borderRadius: BorderRadius.circular(9)),
                    child: Row(children: [
                      Text('🕐 Dernière activation: ${record.lastDateStr}', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                      const Spacer(),
                      Text('× ${record.count}', style: const TextStyle(fontFamily: 'Montserrat', fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.primary)),
                    ])),
                ],
                // Progress
                if (state.busy && state.attempt > 0) ...[
                  const SizedBox(height: 10),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text(state.retryMsg.isNotEmpty ? state.retryMsg : 'Tentative ${state.attempt}/${state.totalTries}', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ]),
                  const SizedBox(height: 4),
                  LinearProgressIndicator(value: state.attempt / state.totalTries.clamp(1, 100),
                    backgroundColor: AppColors.darkSurface3, valueColor: AlwaysStoppedAnimation(c), minHeight: 4),
                ],
                // Result messages
                if (state.isFail) ...[const SizedBox(height: 10),
                  Container(padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: AppColors.errorBg, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.error.withOpacity(0.3))),
                    child: Row(children: [const Icon(Icons.error_outline, color: AppColors.error, size: 16), const SizedBox(width: 8), Expanded(child: Text(state.msg, style: const TextStyle(fontSize: 12, color: AppColors.error, height: 1.4)))]))],
                if (state.isOk) ...[const SizedBox(height: 10),
                  Container(padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: AppColors.successBg, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.success.withOpacity(0.3))),
                    child: Row(children: [const Icon(Icons.check_circle_outline, color: AppColors.success, size: 16), const SizedBox(width: 8), Expanded(child: Text('✅ ${state.msg}', style: const TextStyle(fontFamily: 'Montserrat', fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.success)))]))],
                if (incompatible) ...[const SizedBox(height: 10),
                  Container(padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: AppColors.warningBg, borderRadius: BorderRadius.circular(10)),
                    child: Text('⚠️ Cet offre nécessite une SIM ${svc.requiredSim?.label}', style: const TextStyle(fontSize: 11, color: AppColors.warning)))],
                const SizedBox(height: 12),
                // Button
                SizedBox(height: 48, width: double.infinity,
                  child: ElevatedButton(
                    onPressed: state.busy ? null : onActivate,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: state.isOk ? AppColors.success : c,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
                      elevation: 0,
                    ),
                    child: state.busy
                        ? Row(mainAxisSize: MainAxisSize.min, children: [const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white)), const SizedBox(width: 8), const Text('Activation...')])
                        : Text(state.isOk ? '✅ Activé' : '⚡ Activer ${svc.name}',
                            style: const TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w700, color: Colors.white)),
                  )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String t) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: AppColors.darkSurface2, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.darkBorder)),
    child: Text(t, style: const TextStyle(fontFamily: 'Montserrat', fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textSecondary)),
  );
}
