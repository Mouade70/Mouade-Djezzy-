import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — الإشعارات                              ║
// ║   من تطوير معاذ جلال | @MouadeTEK | 🇩🇿              ║
// ╚══════════════════════════════════════════════════════════╝

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override State<NotificationsScreen> createState() => _NotifsState();
}

class _NotifsState extends State<NotificationsScreen> {
  // Local notification history (activations done in app)
  final List<_Notif> _notifs = [
    _Notif('✅', 'Walk 2GB مفعّل', 'تم تفعيل باقة المشي 2GB بنجاح', DateTime.now().subtract(const Duration(hours:2)), Colors.green),
    _Notif('🤝', 'MGM 1GB مفعّل', 'تم تفعيل 1GB عبر MGM', DateTime.now().subtract(const Duration(hours:5)), Colors.blue),
    _Notif('💳', 'شحن رصيد', 'تم شحن رصيدك بنجاح', DateTime.now().subtract(const Duration(days:1)), Colors.orange),
    _Notif('📡', 'تحديث الرصيد', 'تم تحديث معلومات حسابك', DateTime.now().subtract(const Duration(days:2)), Colors.purple),
  ];

  bool _hasNew = true;

  String _timeAgo(DateTime d) {
    final diff = DateTime.now().difference(d);
    if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} دقيقة';
    if (diff.inHours < 24)   return 'منذ ${diff.inHours} ساعة';
    return 'منذ ${diff.inDays} يوم';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: Row(children: [
          const Text('الإشعارات', style:TextStyle(fontFamily:'NeoSansArabic',fontWeight:FontWeight.w700)),
          if (_hasNew) ...[
            const SizedBox(width:8),
            Container(width:8,height:8,decoration:BoxDecoration(color:AppColors.primary,shape:BoxShape.circle)),
          ],
        ]),
        leading: BackButton(color:AppColors.textPrimary),
        actions: [
          TextButton(
            onPressed: () => setState(() { _hasNew = false; }),
            child: const Text('مقروء', style:TextStyle(color:AppColors.primary,fontFamily:'NeoSansArabic',fontSize:13)),
          ),
        ],
      ),
      body: _notifs.isEmpty
          ? const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
              Text('🔔',style:TextStyle(fontSize:48)),
              SizedBox(height:12),
              Text('لا توجد إشعارات',style:TextStyle(fontFamily:'NeoSansArabic',fontSize:15,color:AppColors.textSecondary)),
            ]))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _notifs.length,
              separatorBuilder: (_,__)=>const SizedBox(height:8),
              itemBuilder: (_,i) {
                final n = _notifs[i];
                return Dismissible(
                  key: Key(n.title+i.toString()),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right:20),
                    decoration: BoxDecoration(color:AppColors.errorBg,borderRadius:BorderRadius.circular(16)),
                    child: const Icon(Icons.delete_rounded,color:AppColors.error),
                  ),
                  onDismissed: (_) => setState(()=>_notifs.removeAt(i)),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds:200),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: i==0&&_hasNew ? n.color.withOpacity(0.07) : AppColors.darkSurface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color:i==0&&_hasNew?n.color.withOpacity(0.3):AppColors.darkBorder),
                    ),
                    child: Row(children:[
                      Container(width:44,height:44,
                        decoration:BoxDecoration(color:n.color.withOpacity(0.12),borderRadius:BorderRadius.circular(13)),
                        child:Center(child:Text(n.emoji,style:const TextStyle(fontSize:22)))),
                      const SizedBox(width:12),
                      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                        Row(children:[
                          Expanded(child:Text(n.title,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:13,fontWeight:FontWeight.w700,color:AppColors.textPrimary))),
                          if(i==0&&_hasNew) Container(width:8,height:8,decoration:BoxDecoration(color:AppColors.primary,shape:BoxShape.circle)),
                        ]),
                        const SizedBox(height:3),
                        Text(n.body,style:const TextStyle(fontSize:11,color:AppColors.textSecondary,height:1.4)),
                        const SizedBox(height:4),
                        Text(_timeAgo(n.time),style:TextStyle(fontSize:10,color:n.color.withOpacity(0.7),fontFamily:'Montserrat')),
                      ])),
                    ]),
                  ),
                );
              },
            ),
    );
  }
}

class _Notif {
  final String emoji,title,body; final DateTime time; final Color color;
  const _Notif(this.emoji,this.title,this.body,this.time,this.color);
}
