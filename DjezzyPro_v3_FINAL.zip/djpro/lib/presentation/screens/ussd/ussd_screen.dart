import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/models/models.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — شاشة أكواد USSD                        ║
// ║   من مطور معاذ جلال | @MouadeTEK | 🇩🇿               ║
// ╚══════════════════════════════════════════════════════════╝

class UssdScreen extends StatefulWidget {
  const UssdScreen({super.key});
  @override State<UssdScreen> createState() => _UssdState();
}

class _UssdState extends State<UssdScreen> {
  String? _copied;
  String _filter = 'الكل';
  static const _cats = ['الكل','رصيد','إنترنت','عروض','شحن','دعم','خدمات','فاتورة','حساب'];

  List<UssdCode> get _shown =>
      _filter == 'الكل' ? allUssdCodes : allUssdCodes.where((c) => c.category == _filter).toList();

  void _copy(String code) {
    Clipboard.setData(ClipboardData(text: code));
    setState(() => _copied = code);
    Future.delayed(const Duration(seconds: 2), () { if (mounted) setState(() => _copied = null); });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 16),
        const SizedBox(width: 8),
        Text('تم نسخ $code', style: const TextStyle(fontFamily:'Montserrat',fontWeight:FontWeight.w600)),
      ]),
      backgroundColor: AppColors.darkSurface2,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      body: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          backgroundColor: AppColors.darkBg,
          elevation: 0,
          title: const Text('أكواد USSD', style: TextStyle(fontFamily:'Montserrat',fontWeight:FontWeight.w800,fontSize:20,color:AppColors.textPrimary)),
          actions: [
            Container(margin:const EdgeInsets.only(right:16),padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),
              decoration:BoxDecoration(color:Color(0xFF8B5CF6).withOpacity(0.15),borderRadius:BorderRadius.circular(10),border:Border.all(color:Color(0xFF8B5CF6).withOpacity(0.3))),
              child:Text('${allUssdCodes.length} كود',style:const TextStyle(fontFamily:'Montserrat',fontSize:11,fontWeight:FontWeight.w700,color:Color(0xFF8B5CF6)))),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(50),
            child: SizedBox(height:50,child:ListView.separated(
              scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:16,vertical:8),
              itemCount:_cats.length,separatorBuilder:(_,__)=>const SizedBox(width:8),
              itemBuilder:(context,i){
                final c=_cats[i]; final sel=_filter==c;
                return GestureDetector(onTap:()=>setState(()=>_filter=c),
                  child:AnimatedContainer(duration:const Duration(milliseconds:200),
                    padding:const EdgeInsets.symmetric(horizontal:14,vertical:6),
                    decoration:BoxDecoration(color:sel?const Color(0xFF8B5CF6):AppColors.darkSurface2,borderRadius:BorderRadius.circular(20),border:Border.all(color:sel?const Color(0xFF8B5CF6):AppColors.darkBorder)),
                    child:Text(c,style:TextStyle(fontFamily:'Montserrat',fontSize:12,fontWeight:FontWeight.w700,color:sel?Colors.white:AppColors.textSecondary))));
              },
            )),
          ),
        ),
        SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(16,12,16,4),
          child:ProCard(padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),
            child:Row(children:[
              const Icon(Icons.touch_app_rounded,color:AppColors.info,size:18),
              const SizedBox(width:10),
              const Expanded(child:Text('اضغط على الكود لنسخه — من مطور معاذ جلال 🇩🇿',
                style:TextStyle(fontSize:12,color:AppColors.textSecondary,height:1.4))),
            ])))),
        SliverPadding(
          padding:const EdgeInsets.fromLTRB(16,8,16,8),
          sliver:SliverList(delegate:SliverChildBuilderDelegate((ctx,i){
            final code=_shown[i];
            return Padding(padding:const EdgeInsets.only(bottom:9),
              child:GestureDetector(onTap:()=>_copy(code.code),
                child:AnimatedContainer(duration:const Duration(milliseconds:200),
                  padding:const EdgeInsets.symmetric(horizontal:16,vertical:12),
                  decoration:BoxDecoration(
                    color:_copied==code.code?AppColors.successBg:AppColors.darkSurface,
                    borderRadius:BorderRadius.circular(14),
                    border:Border.all(color:_copied==code.code?AppColors.success.withOpacity(0.4):AppColors.darkBorder)),
                  child:Row(children:[
                    Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:3),
                      decoration:BoxDecoration(color:code.isFree?AppColors.success.withOpacity(0.15):AppColors.error.withOpacity(0.15),borderRadius:BorderRadius.circular(6)),
                      child:Text(code.isFree?'مجاني':'DA',style:TextStyle(fontFamily:'Montserrat',fontSize:9,fontWeight:FontWeight.w800,color:code.isFree?AppColors.success:AppColors.error))),
                    const SizedBox(width:12),
                    Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                      Text(code.code,style:TextStyle(fontFamily:'Montserrat',fontSize:17,fontWeight:FontWeight.w800,color:_copied==code.code?AppColors.success:AppColors.primary)),
                      Text(code.description,style:const TextStyle(fontSize:12,color:AppColors.textSecondary)),
                    ])),
                    Icon(_copied==code.code?Icons.check_circle_rounded:Icons.copy_rounded,size:18,color:_copied==code.code?AppColors.success:AppColors.textTertiary),
                  ]))));
          },childCount:_shown.length)),
        ),
        SliverPadding(
          padding:const EdgeInsets.symmetric(horizontal:16),
          sliver:SliverToBoxAdapter(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const SectionHeader(title:'أرقام مهمة — خدمة العملاء'),
            ProCard(child:Column(children:[
              _numRow(context,'700','إعادة الشحن (مجاني)',AppColors.success),
              const Divider(color:AppColors.darkBorder,height:1),
              _numRow(context,'777','خدمة العملاء',AppColors.primary),
              const Divider(color:AppColors.darkBorder,height:1),
              _numRow(context,'710','رصيد (5 DA)',AppColors.info),
              const Divider(color:AppColors.darkBorder,height:1),
              _numRow(context,'0770857777','خدمة VIP',Color(0xFF8B5CF6)),
            ])),
            const SizedBox(height:20),
            const DeveloperBadge(),
            const SizedBox(height:8),
            const Center(child:Text('Djezzy Pro v3.0 | من مطور معاذ جلال 🇩🇿',
              style:TextStyle(fontSize:10,color:AppColors.textTertiary,fontFamily:'Montserrat'))),
            const SizedBox(height:24),
          ])),
        ),
      ]),
    );
  }

  Widget _numRow(BuildContext ctx,String num,String desc,Color c)=>GestureDetector(
    onTap:()=>_copy(num),
    child:Padding(padding:const EdgeInsets.symmetric(vertical:10),
      child:Row(children:[
        SizedBox(width:110,child:Text(num,style:TextStyle(fontFamily:'Montserrat',fontSize:17,fontWeight:FontWeight.w800,color:c))),
        Expanded(child:Text(desc,style:const TextStyle(fontSize:13,color:AppColors.textSecondary))),
        Icon(Icons.copy_rounded,size:16,color:AppColors.textTertiary),
      ])));
}
