import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/services/djezzy_api.dart';
import '../../providers/app_provider.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — Auth Screen                             ║
// ║   Developer: Mouad Djallel | @MouadeTEK               ║
// ╚══════════════════════════════════════════════════════════╝

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _AuthState();
}

class _AuthState extends State<AuthScreen> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  int _step = 0; // 0=phone, 1=otp
  final _phoneCtrl = TextEditingController();
  final _otpCtrl   = TextEditingController();
  String _normPhone = '';
  bool _loading = false;
  String? _error;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 350));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _ctrl.forward();
  }

  @override void dispose() { _ctrl.dispose(); _phoneCtrl.dispose(); _otpCtrl.dispose(); super.dispose(); }

  Future<void> _sendOtp() async {
    final n = DjezzyApiService.normPhone(_phoneCtrl.text.trim());
    if (n.isEmpty) {
      setState(() => _error = 'Numéro invalide. Exemple: 0770123456');
      return;
    }
    setState(() { _loading = true; _error = null; _normPhone = n; });
    final ok = await context.read<AppProvider>().sendOtp(n);
    setState(() => _loading = false);
    if (ok) {
      _ctrl.reset(); _ctrl.forward();
      setState(() => _step = 1);
    } else {
      setState(() => _error = 'Échec de l\'envoi. Vérifiez votre réseau Djezzy.');
    }
  }

  Future<void> _verifyOtp() async {
    if (_otpCtrl.text.trim().length < 4) {
      setState(() => _error = 'Code OTP invalide');
      return;
    }
    setState(() { _loading = true; _error = null; });
    final ok = await context.read<AppProvider>().verifyOtp(_normPhone, _otpCtrl.text.trim());
    setState(() => _loading = false);
    if (ok) {
      Navigator.pushReplacementNamed(context, '/main');
    } else {
      setState(() => _error = 'Code incorrect ou expiré');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fade,
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: Column(
              children: [
                const SizedBox(height: 32),
                // Logo
                Container(
                  width: 72, height: 72,
                  decoration: BoxDecoration(
                    gradient: AppColors.primaryGradient,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.4), blurRadius: 24, offset: const Offset(0,8))],
                  ),
                  child: const Icon(Icons.cell_tower_rounded, size: 36, color: Colors.white),
                ),
                const SizedBox(height: 20),
                Text(
                  _step == 0 ? 'Connexion' : 'Vérification',
                  style: const TextStyle(fontFamily: 'Montserrat', fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.textPrimary, letterSpacing: -1),
                ),
                const SizedBox(height: 8),
                Text(
                  _step == 0
                      ? 'Entrez votre numéro Djezzy'
                      : 'Code envoyé à ${maskPhone(_normPhone)}',
                  style: const TextStyle(fontSize: 14, color: AppColors.textSecondary, height: 1.5),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 40),

                // Progress
                Row(
                  children: List.generate(2, (i) => Expanded(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: EdgeInsets.only(right: i == 0 ? 6 : 0, left: i == 1 ? 6 : 0),
                      height: 4,
                      decoration: BoxDecoration(
                        color: i <= _step ? AppColors.primary : AppColors.darkSurface3,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  )),
                ),
                const SizedBox(height: 28),

                // Fields
                if (_step == 0)
                  ProTextField(
                    controller: _phoneCtrl,
                    hint: '07XX XXX XXX',
                    label: 'Numéro Djezzy',
                    prefixIcon: Icons.smartphone_rounded,
                    keyboardType: TextInputType.phone,
                    inputAction: TextInputAction.done,
                    onSubmit: _sendOtp,
                    autofocus: true,
                  )
                else
                  ProTextField(
                    controller: _otpCtrl,
                    hint: '• • • • • •',
                    label: 'Code OTP',
                    prefixIcon: Icons.lock_rounded,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    inputAction: TextInputAction.done,
                    onSubmit: _verifyOtp,
                    autofocus: true,
                  ),

                // Error
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.errorBg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.error.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline, color: AppColors.error, size: 18),
                        const SizedBox(width: 8),
                        Expanded(child: Text(_error!, style: const TextStyle(fontSize: 13, color: AppColors.error))),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 28),

                // Actions
                if (_step == 0)
                  ProButton(label: 'Envoyer le code', icon: Icons.send_rounded, loading: _loading, onTap: _sendOtp)
                else
                  Column(
                    children: [
                      ProButton(label: 'Confirmer', icon: Icons.check_rounded, loading: _loading, onTap: _verifyOtp),
                      const SizedBox(height: 12),
                      ProButton(
                        label: '← Changer de numéro',
                        secondary: true,
                        onTap: () => setState(() { _step = 0; _error = null; _otpCtrl.clear(); }),
                      ),
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: _loading ? null : _sendOtp,
                        child: const Text('Renvoyer le code', style: TextStyle(color: AppColors.primary, fontFamily: 'Montserrat', fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),

                const SizedBox(height: 48),
                const DeveloperBadge(),
                const SizedBox(height: 12),
                const Text('Djezzy Pro v3.0 • dz.mouadetek.djezzypro', style: TextStyle(fontSize: 10, color: AppColors.textTertiary)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
