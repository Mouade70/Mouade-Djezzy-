import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/services/djezzy_api.dart';
import '../../providers/app_provider.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — الصفحة الرئيسية                        ║
// ║   من تطوير معاذ جلال | @MouadeTEK | 🇩🇿              ║
// ╚══════════════════════════════════════════════════════════╝

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<AppProvider>();
    final sub  = prov.subInfo;
    final sess = prov.session;

    return Scaffold(
      backgroundColor: AppColors.darkBg,
      body: RefreshIndicator(
        onRefresh: prov.loadSubInfo,
        color: AppColors.primary,
        backgroundColor: AppColors.darkSurface,
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(parent:AlwaysScrollableScrollPhysics()),
          slivers: [

            // ── Top bar ────────────────────────────────────
            SliverToBoxAdapter(child: SafeArea(
              bottom:false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20,16,20,0),
                child: Row(children:[
                  // Logo
                  Container(width:38,height:38,
                    decoration:BoxDecoration(
                      gradient:AppColors.primaryGradient,
                      borderRadius:BorderRadius.circular(11),
                      boxShadow:[BoxShadow(color:AppColors.primary.withOpacity(0.4),blurRadius:14,offset:const Offset(0,4))]),
                    child:const Icon(Icons.cell_tower_rounded,size:20,color:Colors.white)),
                  const SizedBox(width:10),
                  Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                    const Text('Djezzy',style:TextStyle(fontFamily:'Montserrat',fontSize:17,fontWeight:FontWeight.w900,color:AppColors.textPrimary,letterSpacing:-0.5)),
                    const Text('PRO',style:TextStyle(fontFamily:'Montserrat',fontSize:9,fontWeight:FontWeight.w900,color:AppColors.primary,letterSpacing:2.5)),
                  ]),
                  const Spacer(),
                  if(sess!=null) ...[
                    SimTag(simType:sub.simType),
                    const SizedBox(width:8),
                  ],
                  // Notifications
                  GestureDetector(
                    onTap:()=>Navigator.pushNamed(context,'/notifications'),
                    child:Container(width:38,height:38,
                      decoration:BoxDecoration(color:AppColors.darkSurface2,borderRadius:BorderRadius.circular(11),border:Border.all(color:AppColors.darkBorder)),
                      child:const Icon(Icons.notifications_outlined,size:18,color:AppColors.textSecondary)),
                  ),
                  const SizedBox(width:8),
                  // Refresh
                  GestureDetector(
                    onTap:prov.loadSubInfo,
                    child:Container(width:38,height:38,
                      decoration:BoxDecoration(color:AppColors.darkSurface2,borderRadius:BorderRadius.circular(11),border:Border.all(color:AppColors.darkBorder)),
                      child:prov.subLoading
                          ? const Center(child:SizedBox(width:16,height:16,child:CircularProgressIndicator(strokeWidth:2,color:AppColors.primary)))
                          : const Icon(Icons.refresh_rounded,size:18,color:AppColors.textSecondary)),
                  ),
                ]),
              ),
            )),

            const SliverToBoxAdapter(child:SizedBox(height:18)),

            // ── Balance hero ───────────────────────────────
            SliverToBoxAdapter(child:Padding(
              padding:const EdgeInsets.symmetric(horizontal:16),
              child:_BalanceCard(sub:sub,loading:prov.subLoading,phone:sess?.phone??''),
            )),

            const SliverToBoxAdapter(child:SizedBox(height:10)),

            // ── Internet card ──────────────────────────────
            SliverToBoxAdapter(child:Padding(
              padding:const EdgeInsets.symmetric(horizontal:16),
              child:_InternetCard(sub:sub,loading:prov.subLoading),
            )),

            const SliverToBoxAdapter(child:SizedBox(height:18)),

            // ── Quick actions ──────────────────────────────
            SliverToBoxAdapter(child:Padding(
              padding:const EdgeInsets.symmetric(horizontal:16),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                const SectionHeader(title:'الأدوات السريعة'),
                GridView.count(
                  crossAxisCount:4,
                  shrinkWrap:true,
                  physics:const NeverScrollableScrollPhysics(),
                  crossAxisSpacing:8,mainAxisSpacing:8,
                  childAspectRatio:1.0,
                  children:[
                    _QBtn(Icons.bolt_rounded,         'الخدمات',  AppColors.primary,    '/services'),
                    _QBtn(Icons.people_alt_rounded,   'MGM 1GB',  AppColors.info,       '/mgm'),
                    _QBtn(Icons.directions_walk_rounded,'Walk',   AppColors.success,    '/walk'),
                    _QBtn(Icons.credit_card_rounded,  'شحن',      AppColors.warning,    '/recharge'),
                    _QBtn(Icons.dialpad_rounded,      'USSD',     Color(0xFF8B5CF6),    '/ussd'),
                    _QBtn(Icons.send_rounded,         'مشاركة',   AppColors.info,       '/share'),
                    _QBtn(Icons.history_rounded,      'السجل',    Color(0xFF06B6D4),    '/history'),
                    _QBtn(Icons.speed_rounded,        'السرعة',   Color(0xFFEC4899),    '/speed'),
                  ],
                ),
              ]),
            )),

            const SliverToBoxAdapter(child:SizedBox(height:18)),

            // ── MGM tracker strip ──────────────────────────
            if(sess!=null) SliverToBoxAdapter(child:Padding(
              padding:const EdgeInsets.symmetric(horizontal:16),
              child:_MgmStrip(prov:prov),
            )),

            const SliverToBoxAdapter(child:SizedBox(height:18)),

            // ── Stats grid ────────────────────────────────
            SliverToBoxAdapter(child:Padding(
              padding:const EdgeInsets.symmetric(horizontal:16),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                const SectionHeader(title:'معلومات الحساب'),
                GridView.count(
                  crossAxisCount:2,shrinkWrap:true,
                  physics:const NeverScrollableScrollPhysics(),
                  crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:1.7,
                  children:[
                    StatChip(label:'نوع السيم',  value:sub.simType.label,     icon:Icons.sim_card_rounded,       color:AppColors.primary),
                    StatChip(label:'الشبكة',     value:'4G / 5G',             icon:Icons.signal_cellular_alt_rounded,color:AppColors.info),
                    StatChip(label:'الرقم',      value:sess!=null?maskPhone(sess.phone):'---', icon:Icons.phone_rounded,color:AppColors.success),
                    StatChip(label:'الحالة',     value:'نشط ✓',              icon:Icons.check_circle_rounded,    color:AppColors.success),
                  ],
                ),
              ]),
            )),

            const SliverToBoxAdapter(child:SizedBox(height:18)),

            // ── Footer ────────────────────────────────────
            SliverToBoxAdapter(child:Padding(
              padding:const EdgeInsets.fromLTRB(16,0,16,32),
              child:Column(children:[
                const Divider(color:AppColors.darkBorder),
                const SizedBox(height:12),
                const DeveloperBadge(),
                const SizedBox(height:6),
                const Text('Djezzy Pro v3.0 • من تطوير معاذ جلال 🇩🇿',
                  style:TextStyle(fontSize:10,color:AppColors.textTertiary,fontFamily:'NeoSansArabic'),textAlign:TextAlign.center),
              ]),
            )),
          ],
        ),
      ),
    );
  }
}

// ── Balance Card ──────────────────────────────────────────────
class _BalanceCard extends StatelessWidget {
  final SubInfo sub; final bool loading; final String phone;
  const _BalanceCard({required this.sub,required this.loading,required this.phone});

  @override
  Widget build(BuildContext ctx) => Container(
    padding:const EdgeInsets.all(22),
    decoration:BoxDecoration(
      gradient:AppColors.balanceGradient,
      borderRadius:BorderRadius.circular(24),
      boxShadow:[BoxShadow(color:AppColors.primary.withOpacity(0.3),blurRadius:28,offset:const Offset(0,10))]),
    child:Stack(children:[
      // Decorative circles
      Positioned(right:-18,top:-18,child:Container(width:100,height:100,decoration:BoxDecoration(color:Colors.white.withOpacity(0.06),shape:BoxShape.circle))),
      Positioned(right:50,bottom:-28,child:Container(width:65,height:65,decoration:BoxDecoration(color:Colors.white.withOpacity(0.04),shape:BoxShape.circle))),
      Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[
          const Text('SOLDE',style:TextStyle(fontFamily:'Montserrat',fontSize:10,fontWeight:FontWeight.w700,color:Colors.white70,letterSpacing:2)),
          const Spacer(),
          Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:4),
            decoration:BoxDecoration(color:Colors.white.withOpacity(0.15),borderRadius:BorderRadius.circular(8)),
            child:Text(sub.simType.emoji+'  '+sub.simType.label,
              style:const TextStyle(fontFamily:'Montserrat',fontSize:10,fontWeight:FontWeight.w700,color:Colors.white))),
        ]),
        const SizedBox(height:10),
        loading
          ? Container(width:160,height:52,decoration:BoxDecoration(color:Colors.white.withOpacity(0.15),borderRadius:BorderRadius.circular(10)))
          : Row(crossAxisAlignment:CrossAxisAlignment.end,children:[
              Text(sub.balance??'---',style:const TextStyle(fontFamily:'Montserrat',fontSize:52,fontWeight:FontWeight.w900,color:Colors.white,letterSpacing:-2,height:1)),
              if(sub.balance!=null) Padding(padding:const EdgeInsets.only(bottom:8,left:6),child:const Text('DA',style:TextStyle(fontFamily:'Montserrat',fontSize:18,fontWeight:FontWeight.w600,color:Colors.white70))),
            ]),
        const SizedBox(height:12),
        Wrap(spacing:8,runSpacing:6,children:[
          if(phone.isNotEmpty) _tag('📱  ${maskPhone(phone)}'),
          if(sub.bonus!=null&&sub.bonus!.isNotEmpty) _tag('🎁  ${sub.bonus}'),
        ]),
      ]),
    ]),
  );

  Widget _tag(String t)=>Container(
    padding:const EdgeInsets.symmetric(horizontal:12,vertical:5),
    decoration:BoxDecoration(color:Colors.white.withOpacity(0.18),borderRadius:BorderRadius.circular(10)),
    child:Text(t,style:const TextStyle(fontFamily:'Montserrat',fontSize:11,fontWeight:FontWeight.w600,color:Colors.white)));
}

// ── Internet Card ─────────────────────────────────────────────
class _InternetCard extends StatelessWidget {
  final SubInfo sub; final bool loading;
  const _InternetCard({required this.sub,required this.loading});
  @override
  Widget build(BuildContext ctx) {
    final pct      = sub.usagePct;
    final barColor = pct>80?AppColors.error:pct>55?AppColors.warning:AppColors.info;
    return ProCard(child:Row(children:[
      DataRing(percent:pct,
        centerLabel:loading?'--':(sub.remainingMb!=null?sub.dataStr.split(' ').first:'--'),
        centerSub:loading?'':(sub.remainingMb!=null&&sub.remainingMb!>=1024?'GB':'MB'),
        size:100),
      const SizedBox(width:16),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('INTERNET',style:TextStyle(fontFamily:'Montserrat',fontSize:10,fontWeight:FontWeight.w700,color:AppColors.textSecondary,letterSpacing:2)),
        const SizedBox(height:5),
        if(loading) Container(width:100,height:26,decoration:BoxDecoration(color:AppColors.darkSurface3,borderRadius:BorderRadius.circular(6)))
        else Text(sub.dataStr,style:const TextStyle(fontFamily:'Montserrat',fontSize:22,fontWeight:FontWeight.w800,color:AppColors.textPrimary,letterSpacing:-0.5)),
        if(sub.expiry!=null) Text('Expire: ${sub.expiry}',style:const TextStyle(fontSize:11,color:AppColors.textTertiary)),
        const SizedBox(height:8),
        ClipRRect(borderRadius:BorderRadius.circular(4),
          child:LinearProgressIndicator(value:pct/100,backgroundColor:AppColors.darkSurface3,
            valueColor:AlwaysStoppedAnimation(barColor),minHeight:5)),
        const SizedBox(height:3),
        if(pct>0) Text('${pct.toStringAsFixed(0)}% utilisé',style:TextStyle(fontSize:10,color:barColor)),
      ])),
    ]));
  }
}

// ── Quick Action Button ───────────────────────────────────────
class _QBtn extends StatelessWidget {
  final IconData icon; final String label; final Color color; final String route;
  const _QBtn(this.icon,this.label,this.color,this.route);
  @override
  Widget build(BuildContext ctx)=>GestureDetector(
    onTap:()=>Navigator.pushNamed(ctx,route),
    child:Container(
      decoration:BoxDecoration(color:AppColors.darkSurface,borderRadius:BorderRadius.circular(16),border:Border.all(color:AppColors.darkBorder)),
      child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
        Container(width:36,height:36,
          decoration:BoxDecoration(color:color.withOpacity(0.15),borderRadius:BorderRadius.circular(11)),
          child:Icon(icon,color:color,size:19)),
        const SizedBox(height:5),
        Text(label,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:10,fontWeight:FontWeight.w600,color:AppColors.textPrimary),textAlign:TextAlign.center,maxLines:1,overflow:TextOverflow.ellipsis),
      ]),
    ),
  );
}

// ── MGM Strip ────────────────────────────────────────────────
class _MgmStrip extends StatelessWidget {
  final AppProvider prov;
  const _MgmStrip({required this.prov});
  @override
  Widget build(BuildContext ctx) {
    final rec  = prov.mgmRecord;
    final used = rec.countInPeriod;
    return GestureDetector(
      onTap:()=>Navigator.pushNamed(ctx,'/mgm'),
      child:ProCard(
        padding:const EdgeInsets.symmetric(horizontal:16,vertical:14),
        child:Row(children:[
          Container(width:40,height:40,
            decoration:BoxDecoration(color:AppColors.info.withOpacity(0.12),borderRadius:BorderRadius.circular(12)),
            child:const Icon(Icons.people_alt_rounded,color:AppColors.info,size:20)),
          const SizedBox(width:12),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('MGM — ادعُ صديقاً واحصل على 1GB',style:TextStyle(fontFamily:'NeoSansArabic',fontSize:12,fontWeight:FontWeight.w700,color:AppColors.textPrimary)),
            const SizedBox(height:4),
            Row(children:List.generate(5,(i)=>Expanded(child:Container(
              margin:EdgeInsets.only(right:i<4?4:0),height:5,
              decoration:BoxDecoration(
                color:i<used?AppColors.info:AppColors.darkSurface3,
                borderRadius:BorderRadius.circular(3)))))),
          ])),
          const SizedBox(width:10),
          Column(crossAxisAlignment:CrossAxisAlignment.end,children:[
            Text('$used/5',style:const TextStyle(fontFamily:'Montserrat',fontSize:15,fontWeight:FontWeight.w900,color:AppColors.info)),
            Text(rec.canActivate?'متاح':'مقفل',style:TextStyle(fontSize:10,color:rec.canActivate?AppColors.success:AppColors.warning)),
          ]),
        ]),
      ),
    );
  }
}
