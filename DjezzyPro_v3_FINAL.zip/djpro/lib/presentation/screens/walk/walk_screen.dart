import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/models/service_model.dart';
import '../../providers/app_provider.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — Walk & Win 🚶                          ║
// ║   هدف: 20,000 خطوة = 2GB + 1GB مجاناً               ║
// ║   من تطوير معاذ جلال | @MouadeTEK | 🇩🇿              ║
// ╚══════════════════════════════════════════════════════════╝

class WalkScreen extends StatefulWidget {
  const WalkScreen({super.key});
  @override State<WalkScreen> createState() => _WalkState();
}

class _WalkState extends State<WalkScreen> with TickerProviderStateMixin {
  static const int kGoal = 20000;

  int    _steps   = 0;
  bool   _active  = false;
  double _cals    = 0;
  double _km      = 0;
  int    _secs    = 0;

  // Accelerometer pedometer
  StreamSubscription<AccelerometerEvent>? _sub;
  double _lastMag = 0;
  bool   _flag    = false;
  Timer? _timer;

  late AnimationController _pulse;
  late Animation<double>   _pAnim;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync:this, duration:const Duration(milliseconds:800))..repeat(reverse:true);
    _pAnim = Tween(begin:1.0,end:1.06).animate(CurvedAnimation(parent:_pulse,curve:Curves.easeInOut));
  }

  @override void dispose() { _stop(); _pulse.dispose(); super.dispose(); }

  void _start() {
    setState(()=>_active=true);
    _sub = accelerometerEventStream().listen((e) {
      final mag = sqrt(e.x*e.x + e.y*e.y + e.z*e.z);
      if (mag > 11.5 && _lastMag <= 11.5 && !_flag) {
        _flag = true;
        if (mounted) setState((){
          _steps++; _cals = _steps*0.04; _km = _steps*0.00075;
        });
      } else if (mag <= 11.5) _flag = false;
      _lastMag = mag;
    });
    _timer = Timer.periodic(const Duration(seconds:1), (_){ if(_active&&mounted) setState(()=>_secs++); });
  }

  void _stop() { _sub?.cancel(); _timer?.cancel(); if(mounted) setState(()=>_active=false); }
  void _reset() { _stop(); setState((){_steps=0;_cals=0;_km=0;_secs=0;}); }

  String get _t { final h=_secs~/3600,m=(_secs%3600)~/60,s=_secs%60; return h>0?'${_p(h)}:${_p(m)}:${_p(s)}':'${_p(m)}:${_p(s)}'; }
  String _p(int n) => n.toString().padLeft(2,'0');
  double get pct => (_steps/kGoal).clamp(0.0,1.0);
  bool   get done => _steps >= kGoal;

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<AppProvider>();
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: const Text('Walk & Win 🚶', style:TextStyle(fontFamily:'Montserrat',fontWeight:FontWeight.w800)),
        leading: BackButton(color:AppColors.textPrimary),
        actions: [if(_steps>0) IconButton(icon:const Icon(Icons.refresh_rounded,color:AppColors.textSecondary),onPressed:_reset)],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children:[

          // ── Big ring ────────────────────────────────────
          Center(child: AnimatedBuilder(animation:_pAnim, builder:(ctx,_)=>Transform.scale(
            scale: _active ? _pAnim.value : 1.0,
            child: SizedBox(width:220,height:220,child:Stack(alignment:Alignment.center,children:[
              if(_active) Container(width:220,height:220,decoration:BoxDecoration(shape:BoxShape.circle,boxShadow:[BoxShadow(color:AppColors.primary.withOpacity(0.28),blurRadius:28,spreadRadius:4)])),
              SizedBox(width:220,height:220,
                child:CircularProgressIndicator(value:pct,strokeWidth:14,strokeCap:StrokeCap.round,
                  backgroundColor:AppColors.darkSurface3,
                  valueColor:AlwaysStoppedAnimation(done?AppColors.success:_active?AppColors.primary:AppColors.darkSurface2))),
              Column(mainAxisSize:MainAxisSize.min,children:[
                Text(_steps.toString(),style:TextStyle(fontFamily:'Montserrat',fontSize:50,fontWeight:FontWeight.w900,color:done?AppColors.success:AppColors.textPrimary,letterSpacing:-2)),
                Text('/ ${kGoal ~/ 1000}k خطوة',style:const TextStyle(fontSize:13,color:AppColors.textSecondary,fontFamily:'NeoSansArabic')),
                const SizedBox(height:4),
                Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:3),
                  decoration:BoxDecoration(color:(done?AppColors.success:AppColors.primary).withOpacity(0.15),borderRadius:BorderRadius.circular(8)),
                  child:Text('${(pct*100).toStringAsFixed(1)}%',style:TextStyle(fontFamily:'Montserrat',fontSize:14,fontWeight:FontWeight.w800,color:done?AppColors.success:AppColors.primary))),
              ]),
            ])),
          ))),

          const SizedBox(height:16),

          // ── Stats ────────────────────────────────────────
          Row(children:[
            Expanded(child:_stat('⏱',_t,'وقت')),
            const SizedBox(width:8),
            Expanded(child:_stat('🔥','${_cals.toStringAsFixed(0)}','سعرات')),
            const SizedBox(width:8),
            Expanded(child:_stat('📍','${_km.toStringAsFixed(2)}','كم')),
            const SizedBox(width:8),
            Expanded(child:_stat('🎯','${((kGoal-_steps).clamp(0,kGoal)~/1000)}k','متبقي')),
          ]),

          const SizedBox(height:14),

          // ── Goal reached ─────────────────────────────────
          if(done) ...[
            ProCard(
              color:AppColors.successBg,
              border:Border.all(color:AppColors.success.withOpacity(0.5)),
              child:Column(children:[
                const Text('🎉',style:TextStyle(fontSize:44)),
                const SizedBox(height:6),
                const Text('وصلت للهدف 20,000 خطوة!',style:TextStyle(fontFamily:'NeoSansArabic',fontSize:17,fontWeight:FontWeight.w700,color:AppColors.success)),
                const Text('فعّل مكافأتك الآن 👇',style:TextStyle(fontSize:12,color:AppColors.textSecondary)),
              ]),
            ),
            const SizedBox(height:10),
          ],

          // ── Start / Stop ──────────────────────────────────
          ProButton(
            label: _active ? '⏸  إيقاف' : (_steps>0 ? '▶️  متابعة' : '🚶  ابدأ المشي'),
            color: _active ? AppColors.warning : AppColors.primary,
            onTap: () => _active ? _stop() : _start(),
          ),

          const SizedBox(height:10),

          // ── Rewards ───────────────────────────────────────
          ProCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const SectionHeader(title:'تفعيل المكافآت'),
            ...[
              ('w2g','Walk 2GB','GIFTWALKWIN2GO',AppColors.primary,Icons.directions_walk_rounded),
              ('w1g','Walk 1GB','GIFTWALKWIN1GO',Color(0xFFFF8C00),Icons.directions_run_rounded),
              ('h3g','3GB Combo','',Color(0xFFDC2626),Icons.bolt_rounded),
            ].map((r)=>Padding(
              padding:const EdgeInsets.only(bottom:8),
              child:_rewardTile(prov,r.$1,r.$2,r.$4,r.$5),
            )),
          ])),

          const SizedBox(height:10),

          // ── Tips ─────────────────────────────────────────
          ProCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const SectionHeader(title:'نصائح المشي'),
            _tip('👟','10,000 خطوة تعادل ~7.5 كم'),
            _tip('🔥','20,000 خطوة تحرق ~800 سعرة'),
            _tip('⏱','امشِ 30 دقيقة متواصلة يومياً'),
            _tip('📱','احتفظ بالهاتف في جيبك أثناء المشي'),
            _tip('🎁','20,000 خطوة = 2GB + 1GB مجاناً'),
          ])),

          const SizedBox(height:20),
          const DeveloperBadge(),
          const SizedBox(height:24),
        ]),
      ),
    );
  }

  Widget _stat(String e,String v,String l)=>ProCard(
    padding:const EdgeInsets.symmetric(vertical:12,horizontal:6),
    child:Column(mainAxisSize:MainAxisSize.min,children:[
      Text(e,style:const TextStyle(fontSize:20)),
      const SizedBox(height:5),
      Text(v,style:const TextStyle(fontFamily:'Montserrat',fontSize:13,fontWeight:FontWeight.w800,color:AppColors.textPrimary),textAlign:TextAlign.center),
      Text(l,style:const TextStyle(fontSize:9,color:AppColors.textSecondary)),
    ]),
  );

  Widget _rewardTile(AppProvider prov,String id,String name,Color color,IconData icon){
    final st=prov.svcState(id);
    return Container(
      padding:const EdgeInsets.all(11),
      decoration:BoxDecoration(
        color:st.isOk?AppColors.successBg:AppColors.darkSurface2,
        borderRadius:BorderRadius.circular(13),
        border:Border.all(color:st.isOk?AppColors.success.withOpacity(0.4):st.isFail?AppColors.error.withOpacity(0.3):AppColors.darkBorder)),
      child:Row(children:[
        Container(width:38,height:38,decoration:BoxDecoration(color:color.withOpacity(0.15),borderRadius:BorderRadius.circular(10)),child:Icon(icon,color:color,size:19)),
        const SizedBox(width:10),
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(name,style:const TextStyle(fontFamily:'Montserrat',fontSize:13,fontWeight:FontWeight.w700,color:AppColors.textPrimary)),
          if(st.isOk) Text('✅ ${st.msg}',style:const TextStyle(fontSize:10,color:AppColors.success))
          else if(st.isFail) Text(st.msg,style:const TextStyle(fontSize:10,color:AppColors.error),maxLines:1,overflow:TextOverflow.ellipsis),
        ])),
        if(st.busy) SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2,color:color))
        else GestureDetector(
          onTap:()=>prov.activateService(allServices.firstWhere((s)=>s.id==id)),
          child:Container(
            padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),
            decoration:BoxDecoration(color:st.isOk?AppColors.success:color,borderRadius:BorderRadius.circular(9)),
            child:Text(st.isOk?'✅':'تفعيل',style:const TextStyle(fontFamily:'Montserrat',fontSize:11,fontWeight:FontWeight.w700,color:Colors.white)),
          ),
        ),
      ]),
    );
  }

  Widget _tip(String e,String t)=>Padding(
    padding:const EdgeInsets.symmetric(vertical:5),
    child:Row(children:[
      Text(e,style:const TextStyle(fontSize:16)),
      const SizedBox(width:10),
      Expanded(child:Text(t,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:12,color:AppColors.textSecondary,height:1.4))),
    ]),
  );
}
