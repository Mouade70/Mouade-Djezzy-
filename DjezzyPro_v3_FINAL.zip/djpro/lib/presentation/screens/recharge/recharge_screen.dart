import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../providers/app_provider.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — Recharge Screen                         ║
// ║   Developer: Mouad Djallel | @MouadeTEK               ║
// ╚══════════════════════════════════════════════════════════╝

class RechargeScreen extends StatefulWidget {
  const RechargeScreen({super.key});

  @override
  State<RechargeScreen> createState() => _RechargeScreenState();
}

class _RechargeScreenState extends State<RechargeScreen> {
  final _codeCtrl = TextEditingController();
  bool _loading   = false;
  String? _result;
  bool _resultOk  = false;
  String _display = '';

  // Keypad state
  final _digits = <String>[];

  void _onKeyTap(String key) {
    if (key == '⌫') {
      if (_digits.isNotEmpty) {
        setState(() { _digits.removeLast(); });
      }
    } else if (_digits.length < 16) {
      setState(() { _digits.add(key); });
    }
    _updateDisplay();
  }

  void _updateDisplay() {
    final raw = _digits.join();
    // Format: XXXX XXXX XXXX XXXX
    final chunks = <String>[];
    for (int i = 0; i < raw.length; i += 4) {
      chunks.add(raw.substring(i, (i + 4).clamp(0, raw.length)));
    }
    setState(() { _display = chunks.join(' '); });
    _codeCtrl.text = raw;
  }

  Future<void> _doRecharge() async {
    final code = _codeCtrl.text.trim().replaceAll(' ', '');
    if (code.length < 12) {
      setState(() {
        _result = 'Veuillez saisir un code valide (min. 12 chiffres)';
        _resultOk = false;
      });
      return;
    }

    setState(() { _loading = true; _result = null; });
    final prov = context.read<AppProvider>();
    final res  = await prov.rechargeByCode(code);
    setState(() {
      _loading = false;
      _result  = res.message;
      _resultOk= res.ok;
    });

    if (res.ok) {
      _digits.clear();
      _updateDisplay();
    }
  }

  @override
  Widget build(BuildContext context) {
    final sub = context.watch<AppProvider>().subInfo;

    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: const Text('Recharge'),
        leading: BackButton(color: AppColors.textPrimary),
      ),
      body: Column(
        children: [
          // ── Balance banner ─────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ProCard(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
              child: Row(
                children: [
                  Container(
                    width: 42, height: 42,
                    decoration: BoxDecoration(
                      color: AppColors.warning.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.account_balance_wallet_rounded,
                        color: AppColors.warning, size: 22),
                  ),
                  const SizedBox(width: 14),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Solde actuel', style: TextStyle(
                          fontSize: 11, color: AppColors.textSecondary)),
                      Text(
                        sub.balance != null ? '${sub.balance} DA' : '---',
                        style: const TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // ── Code display ───────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
            child: Column(
              children: [
                const Text(
                  'CODE DE RECHARGE',
                  style: TextStyle(
                    fontFamily: 'Montserrat',
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textSecondary,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 14),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  decoration: BoxDecoration(
                    color: AppColors.darkSurface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: _display.isNotEmpty
                          ? AppColors.primary.withOpacity(0.5)
                          : AppColors.darkBorder,
                    ),
                  ),
                  child: Text(
                    _display.isEmpty ? '• • • • • • • • • • • • • • • •' : _display,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: _display.isEmpty ? 20 : 26,
                      fontWeight: FontWeight.w800,
                      color: _display.isEmpty
                          ? AppColors.textTertiary
                          : AppColors.primary,
                      letterSpacing: _display.isEmpty ? 4 : 3,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ── Result ─────────────────────────────────────────────
          if (_result != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ProCard(
                color: _resultOk ? AppColors.successBg : AppColors.errorBg,
                border: Border.all(
                  color: (_resultOk ? AppColors.success : AppColors.error).withOpacity(0.4),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(
                  children: [
                    Icon(
                      _resultOk ? Icons.check_circle_rounded : Icons.error_rounded,
                      color: _resultOk ? AppColors.success : AppColors.error,
                      size: 22,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _result!,
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: _resultOk ? AppColors.success : AppColors.error,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          const SizedBox(height: 8),

          // ── Numeric keypad ─────────────────────────────────────
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: _Keypad(onTap: _onKeyTap),
            ),
          ),

          // ── Recharge button ─────────────────────────────────────
          Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, MediaQuery.of(context).padding.bottom + 12),
            child: ProButton(
              label: 'Recharger',
              icon: Icons.credit_card_rounded,
              loading: _loading,
              onTap: _digits.length >= 12 ? _doRecharge : null,
              color: _digits.length >= 12 ? AppColors.warning : AppColors.darkSurface3,
            ),
          ),
        ],
      ),
    );
  }
}

class _Keypad extends StatelessWidget {
  final void Function(String) onTap;
  const _Keypad({required this.onTap});

  @override
  Widget build(BuildContext context) {
    const keys = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['', '0', '⌫'],
    ];

    return Column(
      children: keys.map((row) => Expanded(
        child: Row(
          children: row.map((key) => Expanded(
            child: Padding(
              padding: const EdgeInsets.all(5),
              child: key.isEmpty
                  ? const SizedBox()
                  : _KeyButton(key: key, onTap: onTap),
            ),
          )).toList(),
        ),
      )).toList(),
    );
  }
}

class _KeyButton extends StatelessWidget {
  final String key;
  final void Function(String) onTap;

  const _KeyButton({required this.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDelete = key == '⌫';
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          HapticFeedback.lightImpact();
          onTap(key);
        },
        borderRadius: BorderRadius.circular(16),
        child: Ink(
          decoration: BoxDecoration(
            color: isDelete ? AppColors.errorBg : AppColors.darkSurface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.darkBorder),
          ),
          child: Center(
            child: Text(
              key,
              style: TextStyle(
                fontFamily: 'Montserrat',
                fontSize: isDelete ? 20 : 24,
                fontWeight: FontWeight.w600,
                color: isDelete ? AppColors.error : AppColors.textPrimary,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
