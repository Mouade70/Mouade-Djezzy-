// ════════════════════════════════════════════════════════════
// SPLASH SCREEN
// ════════════════════════════════════════════════════════════
// lib/presentation/screens/splash/splash_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../providers/app_provider.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashState();
}

class _SplashState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade, _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _fade  = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.6)));
    _scale = Tween<double>(begin: 0.7, end: 1).animate(CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut));
    _ctrl.forward();
    _navigate();
  }

  void _navigate() async {
    await Future.delayed(const Duration(milliseconds: 2200));
    if (!mounted) return;
    final prov = context.read<AppProvider>();
    Navigator.pushReplacementNamed(context, prov.isLoggedIn ? '/main' : '/auth');
  }

  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      body: Center(
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => FadeTransition(
            opacity: _fade,
            child: ScaleTransition(
              scale: _scale,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 90, height: 90,
                    decoration: BoxDecoration(
                      gradient: AppColors.primaryGradient,
                      borderRadius: BorderRadius.circular(26),
                      boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.5), blurRadius: 35, offset: const Offset(0,12))],
                    ),
                    child: const Icon(Icons.cell_tower_rounded, size: 46, color: Colors.white),
                  ),
                  const SizedBox(height: 22),
                  const Text('Djezzy', style: TextStyle(fontFamily: 'Montserrat', fontSize: 36, fontWeight: FontWeight.w900, color: AppColors.textPrimary, letterSpacing: -1.5)),
                  const Text('PRO', style: TextStyle(fontFamily: 'Montserrat', fontSize: 13, fontWeight: FontWeight.w900, color: AppColors.primary, letterSpacing: 6)),
                  const SizedBox(height: 60),
                  SizedBox(width: 30, height: 30, child: CircularProgressIndicator(strokeWidth: 2.5, color: AppColors.primary.withOpacity(0.6))),
                  const SizedBox(height: 16),
                  const Text('Mouad Djallel | @MouadeTEK', style: TextStyle(fontSize: 11, color: AppColors.textTertiary, fontFamily: 'Montserrat')),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
