import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — حول التطبيق                            ║
// ║   من مطور معاذ جلال | @MouadeTEK | 🇩🇿               ║
// ╚══════════════════════════════════════════════════════════╝

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: const Text('حول التطبيق'),
        leading: BackButton(color: AppColors.textPrimary),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [

          // ── App Banner ────────────────────────────────────────
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
            decoration: BoxDecoration(
              gradient: AppColors.balanceGradient,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.35), blurRadius: 28, offset: const Offset(0,10))],
            ),
            child: Column(children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(22)),
                child: const Icon(Icons.cell_tower_rounded, size: 42, color: Colors.white),
              ),
              const SizedBox(height: 14),
              const Text('Djezzy', style: TextStyle(fontFamily:'Montserrat',fontSize:32,fontWeight:FontWeight.w900,color:Colors.white,letterSpacing:-1)),
              const Text('PRO', style: TextStyle(fontFamily:'Montserrat',fontSize:12,fontWeight:FontWeight.w900,color:Colors.white70,letterSpacing:6)),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                child: const Text('الإصدار 3.0.0', style: TextStyle(fontFamily:'Montserrat',fontSize:12,fontWeight:FontWeight.w700,color:Colors.white)),
              ),
            ]),
          ),
          const SizedBox(height: 16),

          // ── Developer ─────────────────────────────────────────
          ProCard(child: Column(children: [
            const SectionHeader(title: 'المطوّر'),
            Row(children: [
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(16)),
                child: const Icon(Icons.code_rounded, size: 28, color: Colors.white),
              ),
              const SizedBox(width: 14),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('معاذ جلال', style: TextStyle(fontFamily:'Montserrat',fontSize:18,fontWeight:FontWeight.w800,color:AppColors.textPrimary)),
                Text('Mouad Djallel', style: TextStyle(fontSize:13,color:AppColors.textSecondary)),
                SizedBox(height: 4),
                Text('📺 @MouadeTEK  |  🇩🇿 الجزائر', style: TextStyle(fontSize:12,color:AppColors.primary,fontWeight:FontWeight.w600)),
              ])),
            ]),
          ])),
          const SizedBox(height: 12),

          // ── Features ─────────────────────────────────────────
          ProCard(child: Column(children: [
            const SectionHeader(title: 'مميزات التطبيق'),
            ...[
              ('📡', 'تسجيل دخول مباشر بـ OTP'),
              ('💰', 'عرض الرصيد وباقة الإنترنت'),
              ('⚡', '18 خدمة Djezzy'),
              ('🤝', 'MGM — حد 5 مرات كل 16 يوم'),
              ('💳', 'شحن الرصيد بالكود'),
              ('🚶', 'Walk & Win — 3GB مجاناً'),
              ('🔢', 'أكواد USSD مع نسخ'),
              ('👤', 'إدارة حسابات متعددة'),
              ('🌙', 'واجهة داكنة احترافية'),
              ('🔄', 'إعادة المحاولة التلقائية'),
            ].map((f) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Row(children: [
                Text(f.$1, style: const TextStyle(fontSize: 18)),
                const SizedBox(width: 12),
                Text(f.$2, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
              ]),
            )),
          ])),
          const SizedBox(height: 12),

          // ── Tech Stack ────────────────────────────────────────
          ProCard(child: Column(children: [
            const SectionHeader(title: 'تقنيات البناء'),
            ...[
              ('🎯', 'Flutter + Dart'),
              ('🎨', 'Material 3 + تصميم مخصص'),
              ('🌐', 'HTTP مباشر — بدون سيرفر'),
              ('💾', 'SharedPreferences'),
              ('🏗', 'MVVM Architecture'),
              ('📱', 'Android 14 (API 35)'),
              ('🔑', 'apim.djezzy.dz — API رسمي'),
            ].map((t) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Row(children: [
                Text(t.$1, style: const TextStyle(fontSize: 16)),
                const SizedBox(width: 12),
                Text(t.$2, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
              ]),
            )),
          ])),
          const SizedBox(height: 12),

          // ── API Info ─────────────────────────────────────────
          ProCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionHeader(title: 'معلومات الـ API'),
            _infoRow('الـ Base URL', 'apim.djezzy.dz'),
            _infoRow('Package', 'com.djezzy.internet'),
            _infoRow('الإطار الأصلي', 'Flutter 3.x'),
            _infoRow('الإصدار الأصلي', '3.0.3'),
          ])),
          const SizedBox(height: 20),

          // ── Footer ───────────────────────────────────────────
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.08),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.primary.withOpacity(0.25)),
            ),
            child: const Column(children: [
              Text('💜 صُنع بالمحبة في الجزائر 🇩🇿', textAlign: TextAlign.center,
                style: TextStyle(fontFamily:'Montserrat',fontSize:15,fontWeight:FontWeight.w700,color:AppColors.textPrimary)),
              SizedBox(height: 6),
              Text('من مطور معاذ جلال | @MouadeTEK', textAlign: TextAlign.center,
                style: TextStyle(fontSize:13,color:AppColors.primary,fontWeight:FontWeight.w600)),
              SizedBox(height: 4),
              Text('Djezzy Pro v3.0 | dz.mouadetek.djezzypro', textAlign: TextAlign.center,
                style: TextStyle(fontSize:10,color:AppColors.textTertiary,fontFamily:'Montserrat')),
            ]),
          ),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }

  Widget _infoRow(String key, String val) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      SizedBox(width: 120, child: Text(key, style: const TextStyle(fontSize:12,color:AppColors.textTertiary))),
      Expanded(child: Text(val, style: const TextStyle(fontFamily:'Montserrat',fontSize:13,fontWeight:FontWeight.w600,color:AppColors.textPrimary))),
    ]),
  );
}
