import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../providers/app_provider.dart';
import '../../widgets/pro_widgets.dart';
import '../../../data/services/djezzy_api.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — السجل والاستهلاك                       ║
// ║   من تطوير معاذ جلال | @MouadeTEK | 🇩🇿              ║
// ╚══════════════════════════════════════════════════════════╝

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override State<HistoryScreen> createState() => _HistState();
}

class _HistState extends State<HistoryScreen> with SingleTickerProviderStateMixin {
  late TabController _tab;
  bool _loadingH = false, _loadingC = false, _loadingO = false;
  List<dynamic> _history = [], _consumption = [], _offers = [];
  String? _errH, _errC, _errO;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadAll());
  }

  @override void dispose() { _tab.dispose(); super.dispose(); }

  Future<void> _loadAll() async {
    _loadHistory(); _loadConsumption(); _loadOffers();
  }

  Future<void> _loadHistory() async {
    final prov = context.read<AppProvider>();
    if (prov.session == null) return;
    setState(() { _loadingH = true; _errH = null; });
    final r = await DjezzyApiService.i.getHistory(prov.session!.phone, prov.session!.token);
    setState(() {
      _loadingH = false;
      if (r.ok) {
        final d = r.body['data'];
        _history = d is List ? d : (d != null ? [d] : []);
      } else _errH = 'تعذّر تحميل السجل';
    });
  }

  Future<void> _loadConsumption() async {
    final prov = context.read<AppProvider>();
    if (prov.session == null) return;
    setState(() { _loadingC = true; _errC = null; });
    final r = await DjezzyApiService.i.getConsumption(prov.session!.phone, prov.session!.token);
    setState(() {
      _loadingC = false;
      if (r.ok) {
        final d = r.body['data'];
        _consumption = d is List ? d : (d != null ? [d] : []);
      } else _errC = 'تعذّر تحميل الاستهلاك';
    });
  }

  Future<void> _loadOffers() async {
    final prov = context.read<AppProvider>();
    if (prov.session == null) return;
    setState(() { _loadingO = true; _errO = null; });
    final r = await DjezzyApiService.i.getActiveOffers(prov.session!.phone, prov.session!.token);
    setState(() {
      _loadingO = false;
      if (r.ok) {
        final d = r.body['data'];
        _offers = d is List ? d : (d != null ? [d] : []);
      } else _errO = 'تعذّر تحميل العروض';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: const Text('السجل والاستهلاك', style:TextStyle(fontFamily:'NeoSansArabic',fontWeight:FontWeight.w700)),
        leading: BackButton(color:AppColors.textPrimary),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            color: AppColors.primary,
            onPressed: _loadAll,
          ),
        ],
        bottom: TabBar(
          controller: _tab,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textTertiary,
          indicatorColor: AppColors.primary,
          indicatorSize: TabBarIndicatorSize.label,
          labelStyle: const TextStyle(fontFamily:'NeoSansArabic',fontSize:12,fontWeight:FontWeight.w700),
          tabs: const [Tab(text:'سجل الشحن'), Tab(text:'الاستهلاك'), Tab(text:'العروض النشطة')],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _HistoryTab(loading:_loadingH, error:_errH, items:_history, onRefresh:_loadHistory),
          _ConsumptionTab(loading:_loadingC, error:_errC, items:_consumption, onRefresh:_loadConsumption),
          _OffersTab(loading:_loadingO, error:_errO, items:_offers, onRefresh:_loadOffers),
        ],
      ),
    );
  }
}

// ── History Tab ──────────────────────────────────────────────
class _HistoryTab extends StatelessWidget {
  final bool loading; final String? error;
  final List items; final VoidCallback onRefresh;
  const _HistoryTab({required this.loading,required this.error,required this.items,required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child:CircularProgressIndicator(color:AppColors.primary));
    if (error != null) return _ErrorView(msg:error!,onRetry:onRefresh);
    if (items.isEmpty) return _EmptyView(icon:'📜',msg:'لا يوجد سجل شحن بعد');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: items.length,
      separatorBuilder: (_,__)=> const SizedBox(height:9),
      itemBuilder: (_,i) {
        final item = items[i] is Map ? items[i] as Map : {};
        return ProCard(
          padding: const EdgeInsets.symmetric(horizontal:14,vertical:12),
          child: Row(children:[
            Container(width:42,height:42,
              decoration:BoxDecoration(color:AppColors.success.withOpacity(0.12),borderRadius:BorderRadius.circular(12)),
              child:const Icon(Icons.credit_card_rounded,color:AppColors.success,size:20)),
            const SizedBox(width:12),
            Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text(item['type']?.toString() ?? 'شحن رصيد',
                style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:13,fontWeight:FontWeight.w600,color:AppColors.textPrimary)),
              Text(item['date']?.toString() ?? item['timestamp']?.toString() ?? '',
                style:const TextStyle(fontSize:11,color:AppColors.textSecondary)),
            ])),
            Text('+${item['amount']?.toString() ?? '--'} DA',
              style:const TextStyle(fontFamily:'Montserrat',fontSize:14,fontWeight:FontWeight.w800,color:AppColors.success)),
          ]),
        );
      },
    );
  }
}

// ── Consumption Tab ──────────────────────────────────────────
class _ConsumptionTab extends StatelessWidget {
  final bool loading; final String? error;
  final List items; final VoidCallback onRefresh;
  const _ConsumptionTab({required this.loading,required this.error,required this.items,required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child:CircularProgressIndicator(color:AppColors.primary));
    if (error != null) return _ErrorView(msg:error!,onRetry:onRefresh);
    if (items.isEmpty) return _EmptyView(icon:'📊',msg:'لا توجد بيانات استهلاك');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: items.length,
      separatorBuilder: (_,__)=>const SizedBox(height:9),
      itemBuilder: (_,i) {
        final item = items[i] is Map ? items[i] as Map : {};
        final used  = double.tryParse(item['used']?.toString() ?? '0') ?? 0;
        final total = double.tryParse(item['total']?.toString() ?? '0') ?? 1;
        final pct   = (used / total * 100).clamp(0.0,100.0);
        return ProCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[
            const Icon(Icons.data_usage_rounded,color:AppColors.info,size:18),
            const SizedBox(width:8),
            Expanded(child:Text(item['name']?.toString() ?? 'استهلاك البيانات',
              style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:13,fontWeight:FontWeight.w600,color:AppColors.textPrimary))),
            Text('${pct.toStringAsFixed(0)}%',style:TextStyle(fontFamily:'Montserrat',fontSize:12,fontWeight:FontWeight.w700,
              color:pct>80?AppColors.error:pct>55?AppColors.warning:AppColors.info)),
          ]),
          const SizedBox(height:8),
          ClipRRect(borderRadius:BorderRadius.circular(4),
            child:LinearProgressIndicator(value:pct/100,backgroundColor:AppColors.darkSurface3,
              valueColor:AlwaysStoppedAnimation(pct>80?AppColors.error:pct>55?AppColors.warning:AppColors.info),minHeight:5)),
          const SizedBox(height:6),
          Text('${item['used'] ?? '--'} / ${item['total'] ?? '--'} MB',
            style:const TextStyle(fontSize:11,color:AppColors.textSecondary)),
        ]));
      },
    );
  }
}

// ── Offers Tab ───────────────────────────────────────────────
class _OffersTab extends StatelessWidget {
  final bool loading; final String? error;
  final List items; final VoidCallback onRefresh;
  const _OffersTab({required this.loading,required this.error,required this.items,required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child:CircularProgressIndicator(color:AppColors.primary));
    if (error != null) return _ErrorView(msg:error!,onRetry:onRefresh);
    if (items.isEmpty) return _EmptyView(icon:'📦',msg:'لا توجد عروض نشطة حالياً');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: items.length,
      separatorBuilder: (_,__)=>const SizedBox(height:9),
      itemBuilder: (_,i) {
        final item = items[i] is Map ? items[i] as Map : {};
        return ProCard(
          border: Border.all(color:AppColors.success.withOpacity(0.3)),
          child: Row(children:[
            Container(width:44,height:44,
              decoration:BoxDecoration(color:AppColors.success.withOpacity(0.12),borderRadius:BorderRadius.circular(12)),
              child:const Icon(Icons.wifi_rounded,color:AppColors.success,size:22)),
            const SizedBox(width:12),
            Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text(item['name']?.toString() ?? item['packageCode']?.toString() ?? 'عرض نشط',
                style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:13,fontWeight:FontWeight.w600,color:AppColors.textPrimary)),
              if(item['expiryDate']!=null)
                Text('ينتهي: ${item['expiryDate']}',style:const TextStyle(fontSize:11,color:AppColors.textSecondary)),
              if(item['remainingData']!=null)
                Text('${item['remainingData']} MB متبقي',style:const TextStyle(fontSize:11,color:AppColors.info)),
            ])),
            Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),
              decoration:BoxDecoration(color:AppColors.successBg,borderRadius:BorderRadius.circular(8),
                border:Border.all(color:AppColors.success.withOpacity(0.3))),
              child:const Text('نشط',style:TextStyle(fontFamily:'Montserrat',fontSize:11,fontWeight:FontWeight.w700,color:AppColors.success))),
          ]),
        );
      },
    );
  }
}

class _EmptyView extends StatelessWidget {
  final String icon, msg;
  const _EmptyView({required this.icon,required this.msg});
  @override Widget build(BuildContext context) => Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
    Text(icon,style:const TextStyle(fontSize:48)),
    const SizedBox(height:12),
    Text(msg,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:15,color:AppColors.textSecondary)),
  ]));
}

class _ErrorView extends StatelessWidget {
  final String msg; final VoidCallback onRetry;
  const _ErrorView({required this.msg,required this.onRetry});
  @override Widget build(BuildContext context) => Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
    const Icon(Icons.error_outline_rounded,color:AppColors.error,size:44),
    const SizedBox(height:10),
    Text(msg,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:14,color:AppColors.textSecondary)),
    const SizedBox(height:14),
    ElevatedButton.icon(onPressed:onRetry,icon:const Icon(Icons.refresh_rounded,size:16),
      label:const Text('إعادة المحاولة'),
      style:ElevatedButton.styleFrom(backgroundColor:AppColors.primary,foregroundColor:Colors.white,
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12)))),
  ]));
}
