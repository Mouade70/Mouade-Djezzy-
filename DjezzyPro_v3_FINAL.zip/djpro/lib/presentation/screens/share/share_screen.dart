import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/services/djezzy_api.dart';
import '../../providers/app_provider.dart';
import '../../widgets/pro_widgets.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — مشاركة الإنترنت                        ║
// ║   من تطوير معاذ جلال | @MouadeTEK | 🇩🇿              ║
// ╚══════════════════════════════════════════════════════════╝

class ShareScreen extends StatefulWidget {
  const ShareScreen({super.key});
  @override State<ShareScreen> createState() => _ShareState();
}

class _ShareState extends State<ShareScreen> {
  final _targetCtrl = TextEditingController();
  int    _amount    = 500; // MB
  bool   _loading   = false;
  String? _result;
  bool   _ok        = false;

  final List<int> _presets = [100, 250, 500, 1000, 2000];

  @override void dispose() { _targetCtrl.dispose(); super.dispose(); }

  Future<void> _share() async {
    final prov   = context.read<AppProvider>();
    final target = normPhone(_targetCtrl.text.trim());
    if (target.isEmpty || target.length < 12) {
      setState(() { _result = 'أدخل رقم صحيح'; _ok = false; }); return;
    }
    if (prov.session == null) { setState(() { _result = 'سجّل دخول أولاً'; _ok = false; }); return; }
    setState(() { _loading = true; _result = null; });
    final r = await DjezzyApiService.i.shareData(
      prov.session!.phone, prov.session!.token, target, _amount);
    setState(() {
      _loading = false; _ok = r.ok;
      _result = r.message ?? (r.ok ? 'تمت مشاركة $_amount MB بنجاح ✅' : 'فشلت المشاركة');
    });
  }

  @override
  Widget build(BuildContext context) {
    final sub = context.watch<AppProvider>().subInfo;
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      appBar: AppBar(
        title: const Text('مشاركة الإنترنت 📤', style:TextStyle(fontFamily:'NeoSansArabic',fontWeight:FontWeight.w700)),
        leading: BackButton(color:AppColors.textPrimary),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [

          // ── Available balance ────────────────────────────
          ProCard(
            child: Row(children: [
              Container(width:46,height:46,
                decoration:BoxDecoration(color:AppColors.info.withOpacity(0.12),borderRadius:BorderRadius.circular(13)),
                child:const Icon(Icons.wifi_rounded,color:AppColors.info,size:24)),
              const SizedBox(width:14),
              Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                const Text('إنترنت متاح للمشاركة',style:TextStyle(fontSize:11,color:AppColors.textSecondary,fontFamily:'NeoSansArabic')),
                Text(sub.dataStr,style:const TextStyle(fontFamily:'Montserrat',fontSize:22,fontWeight:FontWeight.w800,color:AppColors.textPrimary)),
              ]),
            ]),
          ),

          const SizedBox(height:14),

          // ── Target number ────────────────────────────────
          ProCard(
            child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              const SectionHeader(title:'رقم المستلم'),
              ProTextField(
                controller: _targetCtrl,
                hint: '07XX XXX XXX',
                prefixIcon: Icons.phone_rounded,
                keyboardType: TextInputType.phone,
              ),
            ]),
          ),

          const SizedBox(height:12),

          // ── Amount selector ──────────────────────────────
          ProCard(
            child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              SectionHeader(
                title: 'الكمية',
                trailing: Container(
                  padding:const EdgeInsets.symmetric(horizontal:10,vertical:4),
                  decoration:BoxDecoration(color:AppColors.primary.withOpacity(0.15),borderRadius:BorderRadius.circular(8)),
                  child:Text('$_amount MB',style:const TextStyle(fontFamily:'Montserrat',fontSize:13,fontWeight:FontWeight.w800,color:AppColors.primary))),
              ),
              // Presets
              Wrap(spacing:8,runSpacing:8,children:_presets.map((p)=>GestureDetector(
                onTap:()=>setState(()=>_amount=p),
                child:AnimatedContainer(duration:const Duration(milliseconds:180),
                  padding:const EdgeInsets.symmetric(horizontal:16,vertical:9),
                  decoration:BoxDecoration(
                    color:_amount==p?AppColors.primary:AppColors.darkSurface2,
                    borderRadius:BorderRadius.circular(12),
                    border:Border.all(color:_amount==p?AppColors.primary:AppColors.darkBorder)),
                  child:Text(p>=1000?'${p~/1000} GB':'$p MB',style:TextStyle(
                    fontFamily:'Montserrat',fontSize:13,fontWeight:FontWeight.w700,
                    color:_amount==p?Colors.white:AppColors.textSecondary))),
              )).toList()),

              const SizedBox(height:10),
              // Slider
              SliderTheme(
                data:SliderThemeData(
                  activeTrackColor:AppColors.primary,
                  inactiveTrackColor:AppColors.darkSurface3,
                  thumbColor:AppColors.primary,
                  overlayColor:AppColors.primary.withOpacity(0.15),
                ),
                child:Slider(
                  value:_amount.toDouble(),
                  min:50, max:5000, divisions:99,
                  label:'$_amount MB',
                  onChanged:(v)=>setState(()=>_amount=v.round()),
                ),
              ),
            ]),
          ),

          const SizedBox(height:12),

          // ── Result ───────────────────────────────────────
          if (_result != null) ...[
            ProCard(
              color: _ok?AppColors.successBg:AppColors.errorBg,
              border: Border.all(color:(_ok?AppColors.success:AppColors.error).withOpacity(0.4)),
              padding: const EdgeInsets.all(14),
              child: Row(children:[
                Icon(_ok?Icons.check_circle_rounded:Icons.error_rounded,
                  color:_ok?AppColors.success:AppColors.error,size:22),
                const SizedBox(width:10),
                Expanded(child:Text(_result!,style:TextStyle(
                  fontFamily:'NeoSansArabic',fontSize:13,fontWeight:FontWeight.w600,
                  color:_ok?AppColors.success:AppColors.error))),
              ]),
            ),
            const SizedBox(height:12),
          ],

          // ── Share button ──────────────────────────────────
          ProButton(
            label: 'مشاركة $_amount MB ← 📤',
            icon: Icons.send_rounded,
            loading: _loading,
            color: AppColors.info,
            onTap: _loading ? null : _share,
          ),

          const SizedBox(height:16),

          // ── Info ─────────────────────────────────────────
          ProCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const SectionHeader(title:'ملاحظات'),
            ...[
              'المشاركة متاحة بين مشتركي Djezzy فقط',
              'يجب أن يكون لديك رصيد إنترنت كافٍ',
              'الحد الأدنى: 50 MB',
              'الحد الأقصى: 5 GB',
            ].map((t)=>Padding(
              padding:const EdgeInsets.symmetric(vertical:4),
              child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
                const Text('•',style:TextStyle(color:AppColors.textTertiary,fontSize:16)),
                const SizedBox(width:8),
                Expanded(child:Text(t,style:const TextStyle(fontFamily:'NeoSansArabic',fontSize:12,color:AppColors.textSecondary,height:1.5))),
              ]),
            )),
          ])),

          const SizedBox(height:20),
          const DeveloperBadge(),
          const SizedBox(height:24),
        ]),
      ),
    );
  }
}
