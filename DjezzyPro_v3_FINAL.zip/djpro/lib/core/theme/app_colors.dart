import 'package:flutter/material.dart';

// ╔══════════════════════════════════════════════════════════╗
// ║   Djezzy Pro — Design System                           ║
// ║   Developer: Mouad Djallel | @MouadeTEK               ║
// ╚══════════════════════════════════════════════════════════╝

class AppColors {
  AppColors._();

  // ─── Brand ─────────────────────────────────────────────
  static const Color primary       = Color(0xFFFF5500);
  static const Color primaryLight  = Color(0xFFFF7730);
  static const Color primaryDark   = Color(0xFFCC2200);
  static const Color primarySurface= Color(0xFFFFF0EB);

  // ─── Dark Theme ────────────────────────────────────────
  static const Color darkBg        = Color(0xFF0C0C0F);
  static const Color darkSurface   = Color(0xFF161619);
  static const Color darkSurface2  = Color(0xFF1F1F24);
  static const Color darkSurface3  = Color(0xFF28282E);
  static const Color darkBorder    = Color(0xFF2A2A30);
  static const Color darkBorder2   = Color(0xFF353540);

  // ─── Light Theme ───────────────────────────────────────
  static const Color lightBg       = Color(0xFFF7F6F3);
  static const Color lightSurface  = Color(0xFFFFFFFF);
  static const Color lightSurface2 = Color(0xFFF2F1EE);
  static const Color lightBorder   = Color(0xFFE8E7E3);

  // ─── Text ──────────────────────────────────────────────
  static const Color textPrimary   = Color(0xFFEDEDF0);
  static const Color textSecondary = Color(0xFF8E8E9A);
  static const Color textTertiary  = Color(0xFF55555E);

  // ─── Semantic ──────────────────────────────────────────
  static const Color success       = Color(0xFF00C896);
  static const Color successBg     = Color(0xFF0A2A20);
  static const Color error         = Color(0xFFFF4444);
  static const Color errorBg       = Color(0xFF2A0A0A);
  static const Color warning       = Color(0xFFFFAA00);
  static const Color warningBg     = Color(0xFF2A1E00);
  static const Color info          = Color(0xFF3B82F6);
  static const Color infoBg        = Color(0xFF0A1530);

  // ─── SIM Types ─────────────────────────────────────────
  static const Color simZid        = Color(0xFFE91E63);
  static const Color simLegend     = Color(0xFF8B5CF6);
  static const Color simIzzy       = Color(0xFF10B981);
  static const Color simControl    = Color(0xFF0EA5E9);
  static const Color simPostpaid   = Color(0xFF64748B);

  // ─── Gradients ─────────────────────────────────────────
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFFFF6620), Color(0xFFFF2200)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient darkGradient = LinearGradient(
    colors: [Color(0xFF1A1A20), Color(0xFF0C0C0F)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient balanceGradient = LinearGradient(
    colors: [Color(0xFFFF6620), Color(0xFFCC1100), Color(0xFF8B1500)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    stops: [0, 0.5, 1],
  );
}
