import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_colors.dart';

class AppTheme {
  AppTheme._();

  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    fontFamily: 'Montserrat',
    scaffoldBackgroundColor: AppColors.darkBg,

    colorScheme: const ColorScheme.dark(
      primary:          AppColors.primary,
      onPrimary:        Colors.white,
      primaryContainer: AppColors.primaryDark,
      secondary:        AppColors.success,
      onSecondary:      Colors.black,
      surface:          AppColors.darkSurface,
      onSurface:        AppColors.textPrimary,
      surfaceContainerHighest: AppColors.darkSurface2,
      error:            AppColors.error,
      onError:          Colors.white,
      outline:          AppColors.darkBorder,
    ),

    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontFamily: 'Montserrat',
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: AppColors.textPrimary,
        letterSpacing: -0.5,
      ),
      iconTheme: IconThemeData(color: AppColors.textPrimary),
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.dark,
        systemNavigationBarColor: AppColors.darkBg,
      ),
    ),

    cardTheme: CardTheme(
      color: AppColors.darkSurface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: AppColors.darkBorder, width: 1),
      ),
      margin: EdgeInsets.zero,
    ),

    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: AppColors.darkSurface,
      selectedItemColor: AppColors.primary,
      unselectedItemColor: AppColors.textTertiary,
      showUnselectedLabels: true,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),

    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.darkSurface,
      indicatorColor: AppColors.primary.withOpacity(0.15),
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return const TextStyle(
            fontFamily: 'Montserrat',
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: AppColors.primary,
          );
        }
        return const TextStyle(
          fontFamily: 'Montserrat',
          fontSize: 11,
          color: AppColors.textTertiary,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return const IconThemeData(color: AppColors.primary, size: 24);
        }
        return const IconThemeData(color: AppColors.textTertiary, size: 22);
      }),
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        minimumSize: const Size(double.infinity, 56),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        textStyle: const TextStyle(
          fontFamily: 'Montserrat',
          fontWeight: FontWeight.w700,
          fontSize: 15,
          letterSpacing: 0.3,
        ),
      ),
    ),

    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.darkSurface2,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.darkBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.darkBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.error),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      hintStyle: const TextStyle(color: AppColors.textTertiary, fontSize: 14),
      labelStyle: const TextStyle(color: AppColors.textSecondary, fontSize: 14),
    ),

    textTheme: _textTheme,
  );

  static const TextTheme _textTheme = TextTheme(
    displayLarge:  TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w800, fontSize: 48, letterSpacing: -2),
    displayMedium: TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w800, fontSize: 38, letterSpacing: -1.5),
    displaySmall:  TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w700, fontSize: 28, letterSpacing: -1),
    headlineLarge: TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w700, fontSize: 24, letterSpacing: -0.8),
    headlineMedium:TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w700, fontSize: 20, letterSpacing: -0.5),
    headlineSmall: TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w600, fontSize: 18),
    titleLarge:    TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w700, fontSize: 17),
    titleMedium:   TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w600, fontSize: 15),
    titleSmall:    TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w600, fontSize: 13),
    bodyLarge:     TextStyle(fontFamily: 'NeoSansArabic', fontWeight: FontWeight.w400, fontSize: 16, height: 1.6),
    bodyMedium:    TextStyle(fontFamily: 'NeoSansArabic', fontWeight: FontWeight.w400, fontSize: 14, height: 1.5),
    bodySmall:     TextStyle(fontFamily: 'NeoSansArabic', fontWeight: FontWeight.w400, fontSize: 12, height: 1.4),
    labelLarge:    TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w600, fontSize: 13),
    labelMedium:   TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w500, fontSize: 11, letterSpacing: 0.5),
    labelSmall:    TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w500, fontSize: 10, letterSpacing: 0.8),
  );
}
