// ─── API Constants ─────────────────────────────────────────────────────────
// Developer: Mouad Djallel | @MouadeTEK
// Package: dz.mouadetek.djezzypro

class ApiConstants {
  ApiConstants._();

  static const String baseUrl      = 'https://apim.djezzy.dz/mobile-api';
  static const String clientId     = '87pIExRhxBb3_wGsA5eSEfyATloa';
  static const String clientSecret = 'uf82p68Bgisp8Yg1Uz8Pf6_v1XYa';
  static const String userAgent    = 'okhttp/4.12.0';

  // Auth
  static const String registration = '/oauth2/registration';
  static const String token        = '/oauth2/token';

  // Subscriber
  static String mainBalance(String phone)    => '/api/v1/subscribers/main-balance/$phone';
  static String internetBalance(String phone)=> '/api/v1/subscribers/internet-balance/$phone';
  static String subscriberInfo(String phone) => '/api/v1/subscribers/$phone';

  // Walk & Win
  static String walkReward(String phone)     => '/api/v1/services/walk/activate-reward/$phone';

  // MGM
  static String mgmInvite(String phone)      => '/api/v1/services/mgm/send-invitation/$phone';
  static String mgmReward(String phone)      => '/api/v1/services/mgm/activate-reward/$phone';

  // Offers
  static String offerActivate(String phone)  => '/api/v1/services/offer/activate/$phone';
  static String addonsSubscribe(String phone)=> '/api/v1/services/addons/subscribe/$phone';
  static String offersSubscribe(String phone)=> '/api/v1/offers/subscribe/$phone';

  // Recharge
  static String recharge(String phone)       => '/api/v1/recharge/$phone';
  static String rechargeGift(String phone)   => '/api/v1/recharge/gift/$phone';

  // Services
  static String dataShare(String phone)      => '/api/v1/services/data-sharing/$phone';
  static String notifications(String phone)  => '/api/v1/notifications/$phone';
  static String activeOffers(String phone)   => '/api/v1/subscribers/active-offers/$phone';
  static String consumption(String phone)    => '/api/v1/subscribers/consumption/$phone';
  static String history(String phone)        => '/api/v1/subscribers/recharge-history/$phone';

  // Package codes
  static const Map<String, String> packages = {
    'walk_2gb':      'GIFTWALKWIN2GO',
    'walk_1gb':      'GIFTWALKWIN1GO',
    'gift_weekly':   'GIFTWEEKLY2GO',
    'mgm_1gb':       'MGMBONUS1Go',
    'offre_70da':    'OFFRE70DA4GO',
    'offre_100da':   'OFFRE100DA5GO',
    'offre_200da':   'OFFRE200DA10GO',
    'zid_200':       'ZID200',
    'zid_400':       'ZID400',
    'zid_1000':      'ZID1000',
    'hayla_daily':   'HAYLADAILY',
    'hayla_weekly':  'HAYLAWEEKLY',
    'hayla_monthly': 'HAYLAMONTHLY',
    'legend_50gb':   'LEGEND50GO',
    'legend_80gb':   'LEGEND80GO',
    'hbal_1000':     'HBAL1000',
  };

  // MGM limits
  static const int mgmMaxPerPeriod    = 5;
  static const int mgmPeriodDays      = 16;
  static const int mgmMaxAttempts     = 50;
  static const double mgmAttemptDelay = 1.5;
}
